# Tape Deck 1.3 corresponding source

This is the matching sample-free source for FM-1_915. No stock recordings are included.
The firmware uses two persistent user slots. All generated headers used for the binary
are included under tapedeck/firmware/build/gen; do not regenerate from external sample packs.
Firmware/engines and firmware/bsp are dereferenced copies, not missing submodules.

Build on Linux with Python 3, the JieLi pi32v2 toolchain and the AC79 SDK:
1. Run tapedeck/firmware/tools/get_toolchain.sh to obtain JieLi's compiler.
2. Obtain the AC79 SDK: https://github.com/Jieli-Tech/fw-AC79_AIoT_SDK
3. Set JIELI_TOOLCHAIN to the compiler root and AC79_SDK to the SDK checkout.
4. From tapedeck/firmware run:
   JIELI_DOCKER=0 FELUCCA_CPU2=0 python3 -c 'import sys;sys.path.insert(0,"tools");import build;build.generate=lambda:None;sys.argv=["build.py","--release","1.3-tapedeck"];build.main()'
The original package was built with JieLi's Linux toolchain in an ARM Linux VM using
Rosetta for the x86 compiler. Cache-preserving generate bypass above uses the exact
included fonts/tables/sample-free headers. No original audio is needed.

Web emulator: set PYTHON and EMCC_PY to your Python 3 and Emscripten emcc.py, then run
tapedeck/build-web.sh (tested with Emscripten 4.0.23). Test with Node:
node tapedeck/tests/public.mjs. The test synthesizes temporary tones; none are bundled.

The installer source is under installer/. Serve it on HTTPS or localhost.
License and attribution are in tapedeck/firmware/LICENSE and LICENSING.md.
