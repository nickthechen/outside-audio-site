/* SPDX-License-Identifier: GPL-3.0-only */
static void td_save(void){
 if(!td_ram_valid){td_notice=3;return;}
 td_busy=1;td_silence();int rc=0;unsigned off=SMP_USER_BASE+TD_RECORD_SLOT*SMP_USER_SIZE;
 const smp_user_hdr_t*h=(const smp_user_hdr_t*)td_ram;
#if FELUCCA_WEB
 for(unsigned k=0;k<TD_RAM_BYTES;k+=4096)rc|=st_erase(off+k);
 if(!rc)rc=st_prog(off+512,td_ram+512,h->data_len);
 if(!rc)rc=st_prog(off,td_ram,512);
#else
 uint32_t took;
 for(unsigned k=0;k<TD_RAM_BYTES&&!rc;k+=4096){audio_silence();rc=fl_erase4k(off+k,&took);fm1_wdt_feed();}
 if(!rc)rc=fl_write(off+512,td_ram+512,h->data_len);
 if(!rc)rc=fl_write(off,td_ram,512);
 fm1_irq_off();fl_inval(off,TD_RAM_BYTES);fm1_irq_on();
#endif
 if(!rc){td_ram_valid=0;smp_user_scan(TD_RECORD_SLOT);td_prepare();}
 td_notice=rc?2:1;td_busy=0;
}

/* Explicit library deletion erases the selected user slot, never another slot. */
static void td_delete(unsigned slot){
 if(slot>=SMP_USER_SLOTS){td_notice=2;return;}
 td_busy=1;td_silence();int rc=0;unsigned off=SMP_USER_BASE+slot*SMP_USER_SIZE;
#if FELUCCA_WEB
 for(unsigned k=0;k<SMP_USER_SIZE&&!rc;k+=4096)rc=st_erase(off+k);
#else
 uint32_t took;
 for(unsigned k=0;k<SMP_USER_SIZE&&!rc;k+=4096){audio_silence();rc=fl_erase4k(off+k,&took);fm1_wdt_feed();}
 fm1_irq_off();fl_inval(off,SMP_USER_SIZE);fm1_irq_on();
#endif
 if(slot==TD_RECORD_SLOT)td_ram_valid=0;
 smp_user_scan(slot);memset(td_pattern_lane[slot],255,16);td_prepare();td_notice=rc?2:4;td_busy=0;
}
