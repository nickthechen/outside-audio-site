/* SPDX-License-Identifier: GPL-3.0-only */
static void set_engine_of(track_t *,uint32_t);
static void apply_preset_to(track_t *,uint32_t);
static int td_abs(int x){return x<0?-x:x;}
/* Tape Deck: main-loop sample preparation, audio-owned key/transport events. */
static volatile uint8_t td_busy, td_recording, td_finish;
static volatile uint8_t td_command, td_save_req;
static uint8_t td_source, td_slice, td_transport, td_bank;
/* Pages: tape, modulation, step edit, automatic chops, sequence. */
static uint8_t td_page,td_run,td_arm,td_step,td_edit,td_length=16;
static uint8_t td_hit_vel=110;
static uint8_t td_order,td_rate=2,td_gate=75,td_swing;
static uint8_t td_lshape,td_lrate=2,td_ldest,td_depth;

static uint32_t td_clock,td_duration,td_gate_clock,td_lphase,td_rng=1234567,td_hits;
static int td_lvalue;
static uint16_t td_bpm=126;
static uint8_t td_fx[4]; /* delay send, drive, reverb send, flanger mix */
static uint32_t td_fx_owned,td_fx_prev,td_web_fxkeys;
static volatile uint8_t td_fx_used;
static uint8_t td_fx_down,td_web_fxhold;
static const uint8_t TD_FX_MAP[16]={PF_N,PF_N,PF_N,PF_REV,PF_N,PF_N,PF_TAPE,PF_FRZ,PF_N,PF_N,PF_FLG,PF_PHS,PF_RTHR,PF_N,PF_N,PF_N};
static const char *const TD_FX_NAMES[16]={"Granulize","Scatter","Tremolo","Reverse","Ring mod","Auto pan","Tape stop","Freeze","Wow / flutter","Wavefold","Flanger","Phaser","Reverb throw","Dropout","Distortion","Crush"};
static const uint8_t TD_DIRECT_KEYS[10]={1,3,5,8,10,13,15,17,20,22};
static const char *const TD_DIRECT_NAMES[10]={"OP1 CHOP 1/8","OP2 CHOP 1/16","OP3 CHOP 1/32","OP4 OCTAVE DOWN","OP5 OCTAVE UP","OP6 DELAY 1/8 DOT","PIT DELAY 1/8","GLO DELAY 1/32","MONO LOW PASS","POLY HIGH PASS"};
static unsigned td_direct_inhibit,td_direct_raw,td_web_direct;
static int td_fx_holding(void);
static int td_shift_holding(void);
static unsigned td_oct_raw(void);
static uint8_t td_web_shift,td_web_octup;
static uint8_t td_shift_owned,td_oct_prev,td_perf_keys,td_perf_lane,td_perf_inhibit;

static void td_fx_process(unsigned down,unsigned up){
 int held=td_fx_holding();
 if(held&&!td_fx_down)td_fx_used=0;
 if(held){td_fx_owned|=down;if(down||td_web_fxkeys)td_fx_used=1;}
 td_fx_owned&=~up;
 unsigned keys=0;
 static const uint8_t white[16]={0,2,4,6,7,9,11,12,14,16,18,19,21,23,24,26};
 if(held)for(unsigned i=0;i<16;i++)if(td_fx_owned&(1u<<white[i]))keys|=1u<<i;
 if(held)keys|=td_web_fxkeys;
 perf_latch_on=0;perf_latched=0;
 if(perf_kill)keys=0;
 for(unsigned i=0;i<14;i++)if((keys^td_fx_prev)&(1u<<i))if(TD_FX_MAP[i]<PF_N)perf_press(TD_FX_MAP[i],(keys>>i)&1);
 td_creative_mask=(keys&7)|((keys>>1)&24)|((keys>>3)&96)|((keys>>6)&128);
 perf_k[1]=(keys&(1u<<15))?65:0;
 trk[0].p[P_DLY]=(td_direct&224)?100:td_fx[0];trk[0].p[P_DIST]=(keys&(1u<<14))?100:td_fx[1];
 trk[0].p[P_REV]=td_fx[2];trk[0].p[P_ITYPE]=td_fx[3]?IT_FLANGER:IT_OFF;trk[0].p[P_IMIX]=td_fx[3];
 trk[0].p[P_IA]=36;trk[0].p[P_IB]=90;trk[0].p[P_IC]=64;
 song.g[G_BPM]=td_bpm;
 td_fx_prev=keys;td_fx_down=held;
}
#define td_div td_tapes[td_source].div
#define td_pitch td_tapes[td_source].pitch
#define td_mode td_tapes[td_source].mode
#define td_reverse td_tapes[td_source].reverse
#define td_level td_tapes[td_source].level
static uint8_t td_env_page,td_arp_lane,td_loop[TD_NSOURCES];
static uint8_t td_global_page,td_latch[TD_NSOURCES],td_last_chop[TD_NSOURCES],td_random,td_random_lane,td_random_inhibit,td_web_random;
static uint32_t td_repeat_clock[TD_NSOURCES],td_repeat_period[TD_NSOURCES],td_repeat_step[TD_NSOURCES];
static volatile uint8_t td_delete_req;
static void td_delete(unsigned slot);
static int td_oct_holding(void);
static uint8_t td_key_lane[16];
static uint32_t td_key_age[16],td_lane_gate[TD_NSOURCES],td_lane_gate_age[TD_NSOURCES];
static uint8_t td_pattern_lane[TD_NSOURCES][16],td_velocity_lane[TD_NSOURCES][16],td_gates_lane[TD_NSOURCES][16];
#define td_pattern td_pattern_lane[td_source]
#define td_velocity td_velocity_lane[td_source]
#define td_gates td_gates_lane[td_source]

static char td_label[24];
static uint32_t td_seen_gen;
static uint8_t td_key_notes[16];
static uint32_t td_keys,td_pos,td_last_voice,td_rec_n,td_rec_div;
static int32_t td_rec_pred,td_rec_idx,td_rec_sum,td_peak;
static int16_t td_wave[256];
#define TD_NSTOCK 0


static const char *const TD_NAMES[TD_NSOURCES]={"Tape I","Tape II"};
static const uint8_t TD_DIV[6]={6,0,1,2,3,4};
static void td_save(void);
static void td_silence(void) {
 for(unsigned i=0;i<NVOICE;i++)trk[0].v[i].active=0;
 td_direct_inhibit|=td_direct;td_direct=0;td_creative_mask=0;
 td_perf_keys=0;td_perf_inhibit=td_oct_raw();memset(td_latch,0,sizeof td_latch);td_random=0;td_random_inhibit=td_oct_holding();memset(td_loop,0,sizeof td_loop);memset(td_lane_gate,0,sizeof td_lane_gate);td_transport=0;td_run=0;td_arm=0;td_gate_clock=0;
}
static unsigned td_src_id(unsigned lane){return lane<TD_NSOURCES?lane+1:7;}
static const slc_src_t *td_material(void){return slc_get(td_src_id(td_source));}
static unsigned td_count(void){const slc_src_t*s=td_material();return s?slc_count(s,TD_DIV[td_div]):0;}
static void td_prepare(void){
 td_busy=1;
 trk[0].p[P_E0]=td_src_id(td_source);
 const slc_src_t*s=td_material();memset(td_wave,0,sizeof td_wave);
 if(s){slc_dec_t d;slc_dec_at(&d,0,0);for(unsigned i=0;i<s->len;i++){
  int x=slc_dec_next(s,&d);unsigned j=(uint64_t)i*256/s->len;
  if(td_abs(x)>td_abs(td_wave[j]))td_wave[j]=x;
 }}
 memset(td_label,0,sizeof td_label);
 if(td_source<TD_NSTOCK){for(unsigned j=0;TD_NAMES[td_source][j]&&j<23;j++)td_label[j]=TD_NAMES[td_source][j];}
 else {const smp_user_hdr_t*h=(const smp_user_hdr_t*)smp_user_xip(td_source-TD_NSTOCK);if(usr_nz[td_source-TD_NSTOCK])memcpy(td_label,h->name,8);else memcpy(td_label,"Empty tape",10);}
 td_seen_gen=smp_user_gen;td_slice=0;td_pos=0;td_busy=0;
}
static void td_apply(void){
 trk[0].p[P_E1]=TD_DIV[td_div];trk[0].p[P_E3]=td_pitch;
 trk[0].p[P_E4]=td_mode;trk[0].p[P_E5]=td_reverse;trk[0].p[P_E6]=127;
 trk[0].p[P_E7]=td_tapes[td_source].tone;trk[0].p[P_LEVEL]=100;
}
static void td_trigger_lane(unsigned lane,unsigned slice,int full,unsigned vel){
 const slc_src_t*s=slc_get(td_src_id(lane));if(lane>=TD_NSOURCES||td_busy||td_recording||!s)return;
 td_tape_t*c=&td_tapes[lane];unsigned count=slc_count(s,TD_DIV[c->div]);if(!count)return;
 slice%=count;td_hits++;if(lane==td_source)td_slice=slice;
 track_t*t=&trk[0];int16_t old[P_COUNT];memcpy(old,t->p,sizeof old);
 t->p[P_E0]=td_src_id(lane);t->p[P_E1]=full?6:TD_DIV[c->div];t->p[P_E5]=c->reverse^((td_perf_keys&1)&&lane==td_perf_lane);td_voice_params(t,lane);
 t->v[lane].fine=0;voice_start(t,&t->v[lane],60+slice,vel,0);
 memcpy(t->p,old,sizeof old);td_loop[lane]=full;td_lane_gate[lane]=0;
 td_transport=0;for(unsigned k=0;k<TD_NSOURCES;k++)td_transport|=td_loop[k];
}
static void td_trigger(unsigned slice,int full){td_trigger_lane(td_source,slice,full,td_hit_vel);}
static void td_release_lane(unsigned lane,unsigned age){if(lane<TD_NSOURCES&&trk[0].v[lane].age==age){trk[0].v[lane].gate=0;trk[0].v[lane].stage=3;}}
static void td_chop_key(unsigned slice){
 td_last_chop[td_source]=slice;
 if(td_page==2)td_pattern[td_edit]=slice%32;
 if(td_arm){unsigned j=td_duration?(td_step+td_length-1)%td_length:0;
  if(td_duration&&td_clock>td_duration/2)j=td_step%td_length;
  td_pattern[j]=slice%32;td_velocity[j]=110;td_gates[j]=75;td_edit=j;
 }
 td_trigger(slice,0);
}
static void td_chop_start(void){
 td_run=td_page==3?1:2;td_arp_lane=td_source;td_step=0;td_clock=0;td_duration=0;
}
static void td_modulate(unsigned nframes){
 /* Clocked wave cycle: 4, 2, 1, 1/2, 1/4 beats. 16-bit phase. */
 td_lphase+=(uint32_t)((uint64_t)nframes*td_bpm*65536*(1u<<td_lrate)/(44100u*240u));
 unsigned p=td_lphase&65535;
 int w=td_lshape==0?(p<32768?(int)p*2-32768:98303-(int)p*2):td_lshape==1?(p<32768?32767:-32768):(int)p-32768;
 td_lvalue=w*td_depth/127;
 td_mod_lane=td_source;
 td_mod_pitch=td_ldest==0?td_lvalue*12/32768:0;
 td_mod_tone=td_ldest==1?-td_depth/2+td_lvalue/512:0;
 td_mod_level=td_ldest==2?(-td_depth/2+td_lvalue/512):0;
}
static void td_chop_tick(unsigned nframes){
 for(unsigned k=0;k<TD_NSOURCES;k++)if(td_lane_gate[k]){if(td_lane_gate[k]<=nframes){td_lane_gate[k]=0;td_release_lane(k,td_lane_gate_age[k]);}else td_lane_gate[k]-=nframes;}
 if(!td_run)return;
 if(td_clock>=td_duration){
  td_clock-=td_duration;unsigned j=td_step;
  unsigned base=44100u*60u/(td_bpm*(1u<<td_rate));td_duration=base*(100+((j&1)?-(int)td_swing:(int)td_swing))/100;
  for(unsigned k=0;k<TD_NSOURCES;k++){
   unsigned slice=255,vel=110,gate=td_gate;
   if(td_run==2){slice=td_pattern_lane[k][j];vel=td_velocity_lane[k][j];gate=td_gates_lane[k][j];}
   else if(k==td_arp_lane){const slc_src_t*s=slc_get(td_src_id(k));unsigned n=s?slc_count(s,TD_DIV[td_tapes[k].div]):0;
    if(n){unsigned h=j%n;td_rng=td_rng*1664525u+1013904223u;slice=td_order==0?h:td_order==1?n-1-h:td_order==2?(n>1?(j%(2*n-2)<n?j%(2*n-2):2*n-2-j%(2*n-2)):0):td_rng%n;}}
   if(slice!=255&&!td_latch[k]&&!(td_random&&td_random_lane==k)&&!(td_perf_keys&&td_perf_lane==k)&&!((td_direct&7)&&td_direct_lane==k)){td_trigger_lane(k,slice,0,vel);td_lane_gate[k]=td_duration*gate/100;td_lane_gate_age[k]=trk[0].v[k].age;}
  }
  td_step=(j+1)%td_length;
 }
 td_clock+=nframes;
}
static void td_repeat_tick(unsigned nframes){
 unsigned held=td_oct_holding();if(!held)td_random_inhibit=0;
 unsigned random=held&&!td_random_inhibit;
 if(random&&!td_random){td_random_lane=td_source;td_repeat_clock[td_source]=td_repeat_period[td_source]=0;td_repeat_step[td_source]=0;}
 td_random=random;
 for(unsigned k=0;k<TD_NSOURCES;k++){
  if(!td_latch[k]&&!(random&&k==td_random_lane)&&!(td_perf_keys&&k==td_perf_lane)&&!((td_direct&7)&&k==td_direct_lane))continue;
  if(td_repeat_clock[k]>=td_repeat_period[k]){
   td_repeat_clock[k]-=td_repeat_period[k];unsigned rate=td_rate+((td_perf_keys&2)&&k==td_perf_lane);if(k==td_direct_lane&&(td_direct&7))rate=(td_direct&4)?3:(td_direct&2)?2:1;unsigned base=44100u*60u/(td_bpm*(1u<<rate));
   td_repeat_period[k]=base*(100+((td_repeat_step[k]++&1)?-(int)td_swing:(int)td_swing))/100;
   const slc_src_t*s=slc_get(td_src_id(k));unsigned n=s?slc_count(s,TD_DIV[td_tapes[k].div]):0;
   if(n){unsigned slice=td_last_chop[k]%n;if(random&&k==td_random_lane){td_rng=td_rng*1664525u+1013904223u;slice=td_rng%n;}
    td_trigger_lane(k,slice,0,110);td_lane_gate[k]=td_repeat_period[k]*td_gate/100;td_lane_gate_age[k]=trk[0].v[k].age;}
  }
  td_repeat_clock[k]+=nframes;
 }
}
static void td_record_start(void){
 td_silence();td_rec_n=td_rec_div=0;td_rec_sum=td_rec_pred=td_rec_idx=0;
 td_ram_valid=0;smp_user_gen++;td_recording=1;td_finish=0;
}
/* USB input is 44.1 kHz stereo, captured to 11.025 kHz mono IMA ADPCM.
 * A four-sample box average precedes decimation; intentionally lo-fi, not brickwall bandlimited. */
static void td_capture_pcm(int32_t l,int32_t r){
 if(!td_recording)return;
 td_rec_sum+=(l+r)/2;if(++td_rec_div<4)return;
 int target=td_rec_sum/4;td_rec_sum=0;td_rec_div=0;
 int diff=target-td_rec_pred,code=diff<0?8:0;diff=td_abs(diff);
 int step=IMA_STEP[td_rec_idx],delta=step>>3;
 if(diff>=step){code|=4;diff-=step;delta+=step;}
 if(diff>=step/2){code|=2;diff-=step/2;delta+=step/2;}
 if(diff>=step/4){code|=1;delta+=step/4;}
 td_rec_pred=clamp(td_rec_pred+((code&8)?-delta:delta),-32768,32767);
 td_rec_idx=clamp(td_rec_idx+IMA_IDX[code&7],0,88);
 unsigned off=512+(td_rec_n>>1);
 if(td_rec_n&1)td_ram[off]|=code<<4;else td_ram[off]=code;
 td_rec_n++;
 if(td_rec_n==2*(TD_RAM_BYTES-512)){td_recording=0;td_finish=1;}
}
static uint32_t td_monitor_until;
static int32_t td_monitor_db=-24,td_record_db=0;
static int32_t td_monitor_gain=4096,td_monitor_target=4096,td_record_gain=65536;
static uint32_t td_input_clip_until;
static void td_input_gain(unsigned k,int delta){
 if(k==0){td_monitor_db=clamp(td_monitor_db+delta,-60,0);td_monitor_target=td_monitor_db<=-60?0:pow2_q16(td_monitor_db*3189/100);}
 if(k==1){td_record_db=clamp(td_record_db+delta,-60,0);td_record_gain=td_record_db<=-60?0:pow2_q16(td_record_db*3189/100);}
}

static int td_monitor_active(void){return td_monitor_until&&(int32_t)(td_monitor_until-fm1_ms)>0;}
static void td_input_mix(int32_t *out,int32_t l,int32_t r){
 td_monitor_until=fm1_ms+100;
 if(td_abs(l)>=32760||td_abs(r)>=32760)td_input_clip_until=fm1_ms+500;
 td_capture_pcm(l*td_record_gain/65536,r*td_record_gain/65536);
 int diff=td_monitor_target-td_monitor_gain;
 td_monitor_gain+=diff/128+(diff>0?1:diff<0?-1:0);
 if((diff>0&&td_monitor_gain>td_monitor_target)||(diff<0&&td_monitor_gain<td_monitor_target))td_monitor_gain=td_monitor_target;
 l=l*td_monitor_gain/65536;r=r*td_monitor_gain/65536;
 out[0]=clamp(out[0]+l*(int32_t)song.master_q12/4096,-32768,32767);
 out[1]=clamp(out[1]+r*(int32_t)song.master_q12/4096,-32768,32767);
}
static uint32_t td_crc(const uint8_t*p,unsigned n){uint32_t c=~0u;while(n--){c^=*p++;for(int i=0;i<8;i++)c=(c>>1)^((0u-(c&1))&0xedb88320u);}return ~c;}
static void td_poll(void){
 if(!td_recording&&!td_finish&&td_seen_gen!=smp_user_gen)td_prepare();
 if(td_finish){
  td_busy=1;td_finish=0;
  if(td_rec_n>=64){
   memset(td_ram,0,512);smp_user_hdr_t*h=(smp_user_hdr_t*)td_ram;
   h->magic=SMP_USER_MAGIC;h->version=1;h->nz=1;memcpy(h->name,"REC TAPE",8);
   h->data_len=(td_rec_n+1)/2;h->crc=td_crc(td_ram+512,h->data_len);
   h->zone[0]=(smp_zone_t){0,td_rec_n,0,td_rec_n-1,16384,60*16,0,0,0,127,0};
   td_ram_valid=1;smp_user_scan(TD_RECORD_SLOT);td_source=TD_RECORD_SLOT;td_prepare();
  } else {smp_user_scan(TD_RECORD_SLOT);td_prepare();}
  td_busy=0;
 }
 if(td_delete_req&&!td_recording&&!td_busy){unsigned slot=td_delete_req-1;td_delete_req=0;td_delete(slot);}
 if(td_save_req&&!td_recording&&!td_busy){td_save_req=0;td_save();}
}
static void td_audio(unsigned nframes){
 unsigned raw=td_oct_raw();
 if(td_shift_holding()&&!td_fx_holding())td_shift_owned|=raw&~td_oct_prev;
 td_shift_owned&=raw;td_perf_inhibit&=raw;td_oct_prev=raw;
 unsigned performance=td_shift_holding()&&!td_fx_holding()&&!td_perf_inhibit?td_shift_owned:0;
 if(performance!=td_perf_keys){
  if(performance&&!td_perf_keys)td_perf_lane=td_source;
  td_repeat_clock[td_perf_lane]=td_repeat_period[td_perf_lane]=td_repeat_step[td_perf_lane]=0;
  td_perf_keys=performance;
 }

 unsigned cur=fm1_in.notes,down=cur&~td_keys,up=td_keys&~cur,owned_up=td_fx_owned&up;
 unsigned direct=td_web_direct;
 for(unsigned k=0;k<10;k++)if(cur&(1u<<TD_DIRECT_KEYS[k]))direct|=1u<<k;
 /* FX owns keys pressed under it until release. STOP similarly inhibits holds. */
 for(unsigned k=0;k<10;k++)if((td_fx_owned| (td_fx_holding()?down:0))&(1u<<TD_DIRECT_KEYS[k]))td_direct_inhibit|=1u<<k;
 if(td_fx_holding())td_direct_inhibit|=direct&~td_direct_raw;td_direct_raw=direct;
 td_direct_inhibit&=direct;direct&=~td_direct_inhibit;
 if(td_busy||td_recording||td_finish||perf_kill)direct=0;
 if(direct!=td_direct){
  if(direct&&!td_direct)td_direct_lane=td_source;
  if((direct^td_direct)&7)td_repeat_clock[td_direct_lane]=td_repeat_period[td_direct_lane]=td_repeat_step[td_direct_lane]=0;
  td_direct=direct;
  /* Keep the last delay time for natural tails after releasing the send. */
  if(direct&224)td_delay_rate=(direct&128)?3:(direct&64)?2:1;
 }
 td_keys=cur;td_fx_process(down,up);
 unsigned cmd=td_command;td_command=0;
 if(cmd==1){if(td_page==2||td_page==3||td_page==4){if(td_run)td_silence();else td_chop_start();}else if(td_loop[td_source]){trk[0].v[td_source].active=0;td_loop[td_source]=0;td_transport=0;for(unsigned k=0;k<TD_NSOURCES;k++)td_transport|=td_loop[k];}else td_trigger(0,1);}
 if(cmd==2){td_silence();if(td_recording){td_recording=0;td_finish=1;}}
 if(cmd==4){td_arm=!td_arm;if(td_arm&&td_run!=2){td_run=2;td_step=0;td_clock=td_duration=0;}}
 if(cmd==5){td_pattern[td_edit]=255;}
 if(cmd==6){memset(td_pattern,255,16);}
 if(cmd==7){td_latch[td_source]=!td_latch[td_source];td_repeat_clock[td_source]=td_repeat_period[td_source]=td_repeat_step[td_source]=0;}
 if(cmd==3){if(td_recording){td_recording=0;td_finish=1;}else if(!td_busy)td_record_start();}
 if(cmd==48)td_trigger(0,1);
 if(cmd>=16&&cmd<48&&!td_fx_holding())td_chop_key(cmd-16);
 if(td_busy||td_recording||td_finish){td_keys=fm1_in.notes;return;}

 static const uint8_t white[16]={0,2,4,6,7,9,11,12,14,16,18,19,21,23,24,26};
 for(unsigned i=0;i<16;i++){
  if(!td_fx_holding()&&(down&(1u<<white[i]))){td_key_lane[i]=td_source;td_chop_key(i+16*td_bank);td_key_age[i]=trk[0].v[td_source].age;}
  if((up&~owned_up&(1u<<white[i]))&&td_tapes[td_key_lane[i]].mode!=0&&!td_loop[td_key_lane[i]])td_release_lane(td_key_lane[i],td_key_age[i]);
 }
 td_modulate(nframes);td_repeat_tick(nframes);td_chop_tick(nframes);
 if(trk[0].v[td_source].active){td_pos=trk[0].v[td_source].ph[0];td_last_voice=td_source;}
}
static void td_init(void){
 td_input_gain(0,0);td_monitor_gain=td_monitor_target;
 memset(td_pattern_lane,255,sizeof td_pattern_lane);memset(td_velocity_lane,110,sizeof td_velocity_lane);memset(td_gates_lane,75,sizeof td_gates_lane);
 for(unsigned k=0;k<TD_NSOURCES;k++)td_tapes[k]=(td_tape_t){3,0,0,0,100,0,30,127,127};

 set_engine_of(&trk[0],13);apply_preset_to(&trk[0],0);trk[0].engine=13;eng_mem_claim(&trk[0]);
 trk[0].p[P_VOICE]=V_POLY;trk[0].p[P_CHRD]=trk[0].p[P_AMODE]=0;
 trk[0].p[P_REV]=0;trk[0].p[P_DLY]=0;td_apply();td_prepare();
}
