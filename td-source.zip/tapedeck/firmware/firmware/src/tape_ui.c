/* SPDX-License-Identifier: GPL-3.0-only */
#include "tape_font.h"
static int td_oct_holding(void){return !td_fx_holding()&&(td_web_random||((fm1_in.buttons>>panel.btn[B_OCTDN])&1u));}
static int td_fx_holding(void){return td_web_fxhold||((fm1_in.buttons>>panel.btn[B_FX])&1u);}
#define TD_BODY RGB(59,42,30)
#define TD_FACE RGB(90,67,50)
#define TD_DARK RGB(27,18,12)
#define TD_AMBER RGB(232,163,60)
#define TD_CREAM RGB(243,226,184)
#define TD_RED RGB(255,59,48)
static int td_y,td_vu;static uint32_t td_draw_at,td_angle;
static uint8_t td_fx_button;static uint32_t td_fx_at;
static uint8_t td_delete_armed,td_delete_slot;static uint32_t td_delete_at;
static uint8_t td_notice; /* 1 saved, 2 error, 3 no take */
static void td_px(int x,int y,uint16_t c){cv_pset(x,y-td_y,c);}
static void td_rect(int x,int y,int w,int h,uint16_t c){cv_rect(x,y-td_y,w,h,c);}
static void td_line(int x,int y,int xx,int yy,uint16_t c){cv_line(x,y-td_y,xx,yy-td_y,c);}
static void td_disc(int x,int y,int r,uint16_t c){for(int a=-r;a<=r;a++)for(int b=-r;b<=r;b++)if(a*a+b*b<=r*r)td_px(x+a,y+b,c);}
static int td_sin(unsigned phase){return sine_i(phase<<16);}
static int td_cos(unsigned phase){return td_sin(phase+16384);}
static void td_text(int x,int y,const char*s,uint16_t c){
 for(;*s;s++){unsigned g=(unsigned char)*s;if(g<32||g>126)g=63;
 const uint16_t*f=TD_FONT[g-32];for(int j=0;j<14;j++)for(int i=0;i<12;i++)if(f[j+1]&(1<<i))td_px(x+i,y+j,c);x+=f[0];}
}
static void td_num(int x,int y,int v,uint16_t c){char b[12];fmt_int(b,v);td_text(x,y,b,c);}
static void td_screw(int x,int y){td_disc(x,y+1,3,TD_DARK);td_disc(x,y,2,RGB(166,142,108));td_line(x-1,y+1,x+1,y-1,TD_DARK);}
static void td_reel(int cx,int cy,unsigned progress,int right){
 td_disc(cx+1,cy+3,32,TD_DARK);td_disc(cx,cy,31,RGB(166,144,112));
 td_disc(cx,cy,29,RGB(62,49,37));
 unsigned fill=right?progress:65535-progress;int r=10;
 while(r<28&&(unsigned)(r*r-100)*65535<fill*(28*28-100))r++;
 td_disc(cx,cy,r,RGB(27,19,14));
 for(int rr=12;rr<r;rr+=3)for(unsigned a=0;a<65536;a+=1100)td_px(cx+td_cos(a)*rr/32768,cy+td_sin(a)*rr/32768,RGB(64,44,28));
 for(int arm=0;arm<3;arm++){
  unsigned a=td_angle+arm*65536/3;int x=cx+td_cos(a)*19/32768,y=cy+td_sin(a)*19/32768;
  td_disc(x,y,7,RGB(176,159,132));td_disc(x,y,4,TD_DARK);
  td_line(cx,cy,x,y,RGB(207,189,158));
 }
 td_disc(cx,cy,10,RGB(179,158,124));td_disc(cx-1,cy-1,8,RGB(224,207,172));
 td_disc(cx,cy,4,TD_DARK);td_disc(cx,cy,2,RGB(158,139,112));
 td_line(cx-2,cy,cx+2,cy,RGB(238,222,187));
}
static void td_knob(int x,int y,const char*name,int ratio,int value){
 td_disc(x+1,y+3,14,TD_DARK);td_disc(x,y,13,RGB(154,132,98));td_disc(x,y,11,RGB(43,34,27));
 for(unsigned a=0;a<65536;a+=4096)td_line(x+td_cos(a)*10/32768,y+td_sin(a)*10/32768,x+td_cos(a)*12/32768,y+td_sin(a)*12/32768,RGB(190,167,129));
 unsigned a=24576+ratio*49152/127;td_line(x,y,x+td_cos(a)*9/32768,y+td_sin(a)*9/32768,TD_CREAM);
 td_text(x-17,y-29,name,TD_CREAM);td_num(x-8,y+15,value,TD_AMBER);
}
static void td_button(int x,const char*name,int on){
 td_rect(x,211,44,20,TD_DARK);td_rect(x,210,43,18,on?RGB(115,95,69):RGB(178,157,122));
 td_line(x+1,210,x+41,210,TD_CREAM);td_line(x+42,211,x+42,226,RGB(68,50,34));
 td_text(x+6,212,name,TD_DARK);
}
static unsigned td_slot_bytes(unsigned slot){if(slot>=TD_NSOURCES||!usr_nz[slot])return 0;const smp_user_hdr_t*h=(const smp_user_hdr_t*)smp_user_xip(slot);return h->data_len+512;}
static void td_delete_press(void){
 if(td_page!=7||td_recording)return;if(td_global_page){td_global_page=0;ui.force=1;return;}
 if(td_delete_armed&&td_delete_slot==td_source&&fm1_ms-td_delete_at<3000){td_delete_armed=0;td_delete_req=td_source+1;}
 else {td_notice=0;td_delete_armed=1;td_delete_slot=td_source;td_delete_at=fm1_ms;}ui.force=1;
}
static void td_page_set(unsigned page){if(td_recording||td_finish)return;td_page=td_page==page?0:page;if(td_page!=2&&td_page!=4)td_arm=0;ui.force=1;}
static void td_edit_knob(unsigned k,int d){
 if(td_page==7){if(td_global_page==0){if(k==0){td_source=clamp(td_source+d,0,TD_NSOURCES-1);td_delete_armed=0;td_prepare();}}
  else if(td_global_page==1){if(k==0)td_pitch=clamp(td_pitch+d,-24,24);if(k==1)td_level=clamp(td_level+d,0,127);if(k==2)td_mode=clamp(td_mode+d,0,2);if(k==3)td_reverse=clamp(td_reverse+d,0,1);}
  else {if(k==0)td_bpm=clamp(td_bpm+d,40,240);if(k==1)td_rate=clamp(td_rate+d,0,3);if(k==2)td_swing=clamp(td_swing+d,0,60);if(k==3)td_bank=clamp(td_bank+d,0,1);}}

 if(td_page==6){td_tape_t*c=&td_tapes[td_source];
  if(td_env_page==0){if(k==0)c->div=clamp(c->div+d,0,5);if(k==1)c->pitch=clamp(c->pitch+d,-24,24);if(k==2)c->mode=clamp(c->mode+d,0,2);if(k==3)c->reverse=clamp(c->reverse+d,0,1);}
  if(td_env_page==1){if(k==0)c->attack=clamp(c->attack+d,0,127);if(k==1)c->decay=clamp(c->decay+d,0,127);if(k==2)c->release=clamp(c->release+d,0,127);if(k==3)c->level=clamp(c->level+d,0,127);}
  if(td_env_page==2){if(k==0)c->tone=clamp(c->tone+d,0,127);if(k==1)c->level=clamp(c->level+d,0,127);if(k==2)c->pitch=clamp(c->pitch+d,-24,24);if(k==3)c->reverse=clamp(c->reverse+d,0,1);}
 }
 if(td_page==5){td_fx[k]=clamp(td_fx[k]+d,0,127);}
 if(td_page==1){if(k==0)td_lshape=clamp(td_lshape+d,0,2);if(k==1)td_lrate=clamp(td_lrate+d,0,4);if(k==2)td_ldest=clamp(td_ldest+d,0,2);if(k==3)td_depth=clamp(td_depth+d,0,127);}
 if(td_page==2){if(k==0)td_edit=clamp(td_edit+d,0,td_length-1);if(k==1){int v=td_pattern[td_edit]==255?-1:td_pattern[td_edit];v=clamp(v+d,-1,(int)td_count()-1);td_pattern[td_edit]=v<0?255:v;}if(k==2)td_velocity[td_edit]=clamp(td_velocity[td_edit]+d,1,127);if(k==3)td_gates[td_edit]=clamp(td_gates[td_edit]+d,5,100);}
 if(td_page==3){if(k==0)td_order=clamp(td_order+d,0,3);if(k==1)td_rate=clamp(td_rate+d,0,3);if(k==2)td_gate=clamp(td_gate+d,5,100);if(k==3)td_swing=clamp(td_swing+d,0,60);}
 if(td_page==4){if(k==0){td_length=clamp(td_length+d,1,16);td_edit%=td_length;td_step%=td_length;}if(k==1)td_rate=clamp(td_rate+d,0,3);if(k==2)td_bpm=clamp(td_bpm+d,40,240);if(k==3)td_swing=clamp(td_swing+d,0,60);}
 ui.force=1;
}
static void td_draw(void){
 unsigned now=fm1_ms,dt=now-td_draw_at;if(dt<50&&!ui.force)return;td_draw_at=now;if(dt>100)dt=50;
 const slc_src_t*s=td_material();unsigned pos=s&&s->len?(unsigned)((uint64_t)td_pos*65535/s->len):0;
 if(pos>65535)pos=65535;
 int active=0;for(unsigned i=0;i<NVOICE;i++)active|=trk[0].v[i].active;
 if(active||td_recording)td_angle+=(uint64_t)dt*pow2_q16(td_pitch*16)/1000*(td_reverse?-1:1)/3;
 int target=td_recording?32767:clamp(td_peak*3,0,32767);
 td_vu+=(target-td_vu)*(int)dt/((target>td_vu?80:400)+(int)dt/2);if(td_recording)td_vu=32767;td_peak=0;
 for(td_y=0;td_y<240;td_y+=120){
  cv_begin(240,120,TD_BODY);
  for(int y=td_y;y<td_y+120;y++){
   unsigned h=(y*173u+17u)^(y*37u);td_rect(0,y,240,1,RGB(49+(h%16),34+(h%11),24+(h%7)));
  }
  td_rect(7,7,228,228,TD_DARK);td_rect(6,5,227,228,TD_FACE);
  td_line(7,5,231,5,RGB(132,104,76));td_line(6,6,6,231,RGB(114,87,62));
  for(int y=8;y<230;y+=3)td_line(9,y,230,y,RGB(87,64,48));
  td_screw(13,13);td_screw(226,13);td_screw(13,225);td_screw(226,225);
  td_rect(87,15,67,51,TD_DARK);td_rect(89,17,63,46,RGB(206,186,145));
  td_rect(90,18,61,43,TD_CREAM);
  for(int i=0;i<=28;i++){
   unsigned a=35000+i*28000/28;int x=120+td_cos(a)*27/32768,y=57+td_sin(a)*27/32768;
   td_disc(x,y,1,i>=21?TD_RED:TD_DARK);
   if(!(i%4))td_line(x,y,120+td_cos(a)*23/32768,57+td_sin(a)*23/32768,TD_DARK);
  }
  unsigned needle=35000+td_vu*28000/32767;
  td_line(120,57,120+td_cos(needle)*27/32768,57+td_sin(needle)*27/32768,TD_RED);
  td_disc(120,57,3,TD_DARK);td_text(111,39,"VU",TD_DARK);
  td_reel(49,49,pos,0);td_reel(190,49,pos,1);
  td_line(25,67,29,85,TD_DARK);td_line(213,67,210,85,TD_DARK);
  td_rect(23,85,194,19,TD_DARK);td_line(23,85,216,85,RGB(143,112,72));
  for(unsigned x=24;x<216;x++){
   int idx=(int)(pos*256/65536)+(int)(x-24)*256/192-128;
   if(idx<0||idx>=256)continue;
   int amp=td_wave[idx]*7/32768;
   td_px(x,94+amp,TD_AMBER);td_px(x,95+amp,RGB(155,105,35));
  }
  if(s){for(unsigned j=0;j<td_count();j++){
   uint32_t a,b,st;slc_bounds(s,TD_DIV[td_div],j,&a,&b,&st);
   int x=120+(int)((int64_t)a*192/s->len)-(int)(pos*192/65535);
   if(x>=24&&x<216){td_line(x,86,x,101,TD_CREAM);td_rect(x-1,83,3,3,TD_CREAM);}
  }}
  if(!td_fx_holding()&&(td_page==6||td_page==7)){
   unsigned current=td_page==6?td_env_page:td_global_page;
   for(unsigned k=0;k<3;k++){int x=107+k*13;td_disc(x,76,4,TD_DARK);td_disc(x,76,2,k==current?TD_CREAM:TD_FACE);}
  }
  if(!td_page&&td_monitor_active())td_text(95,67,"USB IN",TD_AMBER);
  td_rect(118,84,4,20,TD_RED);td_disc(27,94,4,RGB(178,154,117));td_disc(212,94,4,RGB(178,154,117));
  if(!td_page){td_knob(37,140,"Tape",td_source*127/(TD_NSOURCES-1),td_source+1);
  td_knob(92,140,"Splices",td_div*127/5,td_count());
  td_knob(147,140,"Pitch",(td_pitch+24)*127/48,td_pitch);
  td_knob(202,140,"Level",td_level,td_level);}
  if(td_page==1){td_knob(37,140,"Shape",td_lshape*63,td_lshape+1);td_knob(92,140,"Rate",td_lrate*31,td_lrate+1);td_knob(147,140,"Dest",td_ldest*63,td_ldest+1);td_knob(202,140,"Depth",td_depth,td_depth);}
  if(td_page==2){td_knob(37,140,"Step",td_edit*127/15,td_edit+1);td_knob(92,140,"Slice",td_pattern[td_edit]==255?0:td_pattern[td_edit]*127/32,td_pattern[td_edit]==255?0:td_pattern[td_edit]+1);td_knob(147,140,"Vel",td_velocity[td_edit],td_velocity[td_edit]);td_knob(202,140,"Gate",td_gates[td_edit]*127/100,td_gates[td_edit]);}
  if(td_page==3){td_knob(37,140,"Order",td_order*42,td_order+1);td_knob(92,140,"Rate",td_rate*42,td_rate+1);td_knob(147,140,"Gate",td_gate*127/100,td_gate);td_knob(202,140,"Swing",td_swing*127/60,td_swing);}
  if(td_page==7&&td_global_page==1){td_knob(37,140,"Pitch",(td_pitch+24)*127/48,td_pitch);td_knob(92,140,"Level",td_level,td_level);td_knob(147,140,"Mode",td_mode*63,td_mode);td_knob(202,140,"Reverse",td_reverse*127,td_reverse);}
  if(td_page==7&&td_global_page==2){td_knob(37,140,"BPM",(td_bpm-40)*127/200,td_bpm);td_knob(92,140,"Rate",td_rate*42,td_rate+1);td_knob(147,140,"Swing",td_swing*127/60,td_swing);td_knob(202,140,"Bank",td_bank*127,td_bank+1);}
  if(td_page==6){td_tape_t*c=&td_tapes[td_source];
   if(td_env_page==0){td_knob(37,140,"Splice",c->div*127/5,td_count());td_knob(92,140,"Pitch",(c->pitch+24)*127/48,c->pitch);td_knob(147,140,"Mode",c->mode*63,c->mode);td_knob(202,140,"Reverse",c->reverse*127,c->reverse);}
   if(td_env_page==1){td_knob(37,140,"Attack",c->attack,c->attack);td_knob(92,140,"Decay",c->decay,c->decay);td_knob(147,140,"Release",c->release,c->release);td_knob(202,140,"Level",c->level,c->level);}
   if(td_env_page==2){td_knob(37,140,"Tone",c->tone,c->tone);td_knob(92,140,"Level",c->level,c->level);td_knob(147,140,"Pitch",(c->pitch+24)*127/48,c->pitch);td_knob(202,140,"Reverse",c->reverse*127,c->reverse);}
  }
  if(td_page==5){td_knob(37,140,"Delay",td_fx[0],td_fx[0]);td_knob(92,140,"Drive",td_fx[1],td_fx[1]);td_knob(147,140,"Reverb",td_fx[2],td_fx[2]);td_knob(202,140,"Flange",td_fx[3],td_fx[3]);}
  if(td_page==4){td_knob(37,140,"Steps",td_length*127/16,td_length);td_knob(92,140,"Rate",td_rate*42,td_rate+1);td_knob(147,140,"BPM",(td_bpm-40)*127/200,td_bpm);td_knob(202,140,"Swing",td_swing*127/60,td_swing);}
  if(td_page==2||td_page==4){for(unsigned j=0;j<16;j++){int x=24+j*12;td_rect(x,73,10,9,TD_DARK);td_rect(x+1,74,8,6,j>=td_length?TD_FACE:td_run&&j==(td_step+td_length-1)%td_length?TD_RED:j==td_edit?TD_CREAM:td_pattern[j]==255?TD_DARK:TD_AMBER);}}
  if(td_page==1){td_rect(86,68,68,14,TD_DARK);for(unsigned j=0;j<64;j++){int w=td_lshape==0?(j<32?j:63-j):td_lshape==1?(j<32?31:0):j/2;td_px(88+j,79-w/3,TD_AMBER);}td_line(88+(td_lphase&65535)*63/65536,69,88+(td_lphase&65535)*63/65536,80,TD_CREAM);}
  td_rect(20,174,202,31,TD_DARK);td_rect(18,171,202,31,TD_CREAM);
  td_line(19,172,219,172,RGB(255,242,210));td_line(19,188,219,188,RGB(190,167,128));
  if((td_page==2||td_page==4||td_page==6)&&!td_recording){td_text(25,173,td_page==2?"EDIT":td_page==4?"SEQ":"ENV",TD_DARK);td_num(59,173,td_source+1,TD_DARK);td_text(74,173,td_label,TD_DARK);}
  else td_text(25,173,td_recording?"REC":td_page?(const char*[]){"","LFO modulation","EDIT chop steps","ARP chop player","SEQ live overdub","FX tape rack","ENV tape properties","GLOBAL library"}[td_page]:td_label,TD_DARK);
  if(td_recording)td_disc(52,181,3,TD_RED);
  if(td_notice)td_text(170,173,td_notice==1?"Saved":td_notice==2?"Error":td_notice==4?"Erased":"No take",TD_DARK);
  if(!td_page){td_num(25,188,td_count(),TD_DARK);td_text(42,188,"slices",TD_DARK);
  td_num(87,188,td_bpm,TD_DARK);td_text(109,188,"BPM",TD_DARK);
  td_text(155,188,td_recording?"USB in":td_reverse?"Reverse":(const char*[]){"One shot","Gated","Loop"}[td_mode],TD_DARK);}
  else if(td_page==7){td_text(25,188,td_global_page==1?"Sample / ENV: more":"Device v1.1 / GLO: next",TD_DARK);}
  else if(td_page==6){td_text(25,188,(const char*[]){"Playback / ENV: next","Envelope / ENV: next","Tone+mix / ENV: next"}[td_env_page],TD_DARK);}
  else if(td_page==5){td_text(25,188,"0 = off / Hold FX + keys",TD_DARK);}
  else if(td_page==1){td_text(25,188,(const char*[]){"Triangle","Square","Saw"}[td_lshape],TD_DARK);td_text(86,188,(const char*[]){"4 beats","2 beats","1 beat","1/2 beat","1/4 beat"}[td_lrate],TD_DARK);td_text(160,188,(const char*[]){"Pitch","Tone","Level"}[td_ldest],TD_DARK);}
  else {td_text(25,188,td_arm?"LIVE: tap chops":td_page==2?"REC: clear step":td_page==3?(const char*[]){"Forward","Reverse","Pendulum","Random"}[td_order]:"REC: live overdub",TD_DARK);td_text(151,188,(const char*[]){"1/4","1/8","1/16","1/32"}[td_rate],TD_DARK);td_num(188,188,td_bpm,TD_DARK);}
  td_button(23,"Play",td_transport||td_run||td_random||td_latch[td_source]);td_button(73,"Stop",!active);td_button(123,"Rec",td_recording||td_arm);td_button(173,"Save",0);
  if(td_random||td_latch[td_source])td_text(88,65,td_random?"RANDOM":"LATCH",TD_AMBER);
  if(td_page==7&&!td_global_page){
   td_rect(18,109,204,94,TD_DARK);td_rect(19,110,202,92,TD_FACE);td_text(25,110,"DEVICE TAPES / K1 selects",TD_CREAM);
   for(unsigned k=0;k<TD_NSOURCES;k++){int y=127+k*16;td_rect(23,y,194,15,k==td_source?TD_CREAM:TD_DARK);uint16_t col=k==td_source?TD_DARK:TD_CREAM;td_num(26,y,k+1,col);
    char label[9]={0};if(usr_nz[k])memcpy(label,((const smp_user_hdr_t*)smp_user_xip(k))->name,8);else memcpy(label,"Empty",5);
    td_text(40,y,label,col);td_num(121,y,(td_slot_bytes(k)+1023)/1024,col);td_text(140,y,k==TD_RECORD_SLOT&&td_ram_valid?"/32K":"/80K",col);td_text(175,y,k==TD_RECORD_SLOT&&td_ram_valid?"RAM":"Flash",col);}
   td_text(25,177,td_delete_armed&&td_delete_slot==td_source&&fm1_ms-td_delete_at<3000?"REC again: DELETE tape":"PLAY preview / REC delete",TD_AMBER);
   td_text(25,190,"GLO: settings / SAVE: keep RAM",TD_CREAM);
  }
  if(td_fx_holding()){
   td_rect(18,109,204,94,TD_DARK);td_rect(19,110,202,92,TD_FACE);
   td_text(25,111,"PUNCH IN / hold keys",TD_CREAM);
   static const char *const shortnames[16]={"R8","R16","R32","REV","LP","HP","STP","FRZ","+8","-8","FLG","PHS","VRB","ECH","DRV","BIT"};
   for(unsigned j=0;j<16;j++){int x=23+(j%4)*49,y=125+(j/4)*15;int on=(td_fx_prev>>j)&1;td_rect(x+1,y+1,47,14,TD_DARK);td_rect(x,y,46,13,on?TD_AMBER:TD_CREAM);td_num(x+1,y,j+1,TD_DARK);td_text(x+17,y,shortnames[j],TD_DARK);}
   unsigned last=16;for(unsigned j=0;j<16;j++)if(td_fx_prev&(1u<<j))last=j;
   td_text(25,187,last<16?TD_FX_NAMES[last]:"Release to return",TD_CREAM);
  }
  cv_blit(0,td_y);
 }
 ui.force=0;
}
static int td_ui_input(uint32_t pressed){
 td_poll();perf_kill=ui.uboot||ui.menu||ui.confirm;if(perf_kill)return 0;
 unsigned held=td_fx_holding();
 if(held&&!td_fx_button){td_fx_at=fm1_ms;td_fx_button=1;}
 if(!held&&td_fx_button){td_fx_button=0;if(!td_fx_used&&fm1_ms-td_fx_at<350)td_page_set(5);ui.force=1;}
 if(held)return 1;
 int s;
 if((pressed>>panel.btn[B_PLAY])&1)td_command=1;
 if((pressed>>panel.btn[B_REC])&1){if(td_page==7){td_delete_press();}else if((fm1_in.buttons>>panel.btn[B_EDIT])&1u){td_command=6;td_page=2;}else td_command=td_page==2?5:td_page==4?4:3;}
 if((pressed>>panel.btn[B_HOME])&1){td_command=2;td_page=0;td_arm=0;}
 if((pressed>>panel.btn[B_SAVE])&1){td_notice=0;td_save_req=1;}

 if((pressed>>panel.btn[B_OCTUP])&1)td_command=7;
 if((pressed>>panel.btn[B_GLO])&1){td_delete_armed=0;if(td_page==7)td_global_page=(td_global_page+1)%3;else {td_global_page=0;td_page_set(7);}}
 if((pressed>>panel.btn[B_ENV])&1){if(td_page==6)td_env_page=(td_env_page+1)%3;else td_page_set(6);}
 if((pressed>>panel.btn[B_LFO])&1)td_page_set(1);
 if((pressed>>panel.btn[B_EDIT])&1)td_page_set(2);
 if((pressed>>panel.btn[B_ARP])&1)td_page_set(3);
 if((pressed>>panel.btn[B_SEQ])&1)td_page_set(4);
 if(td_recording||td_finish)return 1;
 if((s=panel_enc(EN_PRESET))){td_source=clamp(td_source+s,0,TD_NSOURCES-1);td_prepare();}
 if(td_page){const unsigned knobs[4]={EN_K1,EN_K2,EN_K3,EN_K4};for(unsigned k=0;k<4;k++)if((s=panel_enc(knobs[k])))td_edit_knob(k,s);if((s=panel_enc(EN_SELECT)))td_bpm=clamp(td_bpm+s,40,240);return 1;}
 if((s=panel_enc(EN_K1))){td_source=clamp(td_source+s,0,TD_NSOURCES-1);td_prepare();}
 if((s=panel_enc(EN_K2))){td_div=clamp(td_div+s,0,5);}
 if((s=panel_enc(EN_K3)))td_pitch=clamp(td_pitch+s,-24,24);
 if((s=panel_enc(EN_K4)))td_level=clamp(td_level+s,0,127);
 if((s=panel_enc(EN_SELECT)))td_bpm=clamp(td_bpm+s,40,240);
 if((s=panel_enc(EN_ALGO)))td_mode=clamp(td_mode+s,0,2);
 td_apply();return 1;
}
