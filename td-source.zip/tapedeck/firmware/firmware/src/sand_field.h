/* SPDX-License-Identifier: GPL-3.0-only
 * Sandgrain prototype, 2026. A bounded integer sand field shared by device and web.
 * 110 x 54 one-byte cells = 5940 bytes. No heap, floats, or work in audio ISR. */
#define SAND_W 110
#define SAND_H 54
static uint8_t sand_cells[SAND_W * SAND_H];
static uint32_t sand_seed = 0x53414e44u, sand_clock;
static uint32_t sand_rand(void) {
    sand_seed ^= sand_seed << 13; sand_seed ^= sand_seed >> 17; sand_seed ^= sand_seed << 5;
    return sand_seed;
}
static void sand_step(uint32_t now, uint32_t position, uint32_t spread, uint32_t density, uint32_t sounding) {
    int x, y, d, nx; uint32_t i;
    if (now - sand_clock < 40u) return; /* at most 25 Hz, never catch up in a burst */
    sand_clock = now;
    /* Drain a few bottom cells so the instrument never fills permanently. */
    for (i = 0; i < 6; ++i) sand_cells[(SAND_H - 1) * SAND_W + sand_rand() % SAND_W] = 0;
    for (y = SAND_H - 2; y >= 0; --y) {
        int reverse = (int)(sand_rand() & 1u);
        for (i = 0; i < SAND_W; ++i) {
            x = reverse ? SAND_W - 1 - (int)i : (int)i;
            uint8_t c = sand_cells[y * SAND_W + x];
            if (!c) continue;
            nx = x;
            if (sand_cells[(y + 1) * SAND_W + x]) {
                d = (sand_rand() & 1u) ? 1 : -1; nx = x + d;
                if (nx < 0 || nx >= SAND_W || sand_cells[(y + 1) * SAND_W + nx]) nx = x - d;
                if (nx < 0 || nx >= SAND_W || sand_cells[(y + 1) * SAND_W + nx]) continue;
            }
            sand_cells[(y + 1) * SAND_W + nx] = c; sand_cells[y * SAND_W + x] = 0;
        }
    }
    if (!sounding) return;
    for (i = 0; i < 1u + density / 12u; ++i) {
        x = (int)(position * (SAND_W - 1) / 127u) +
            ((int)(sand_rand() % 127u) - 63) * (int)spread / 160;
        if (x < 0) x = 0; if (x >= SAND_W) x = SAND_W - 1;
        sand_cells[x] = 1u + sand_rand() % 4u;
    }
}
