/* SPDX-License-Identifier: GPL-3.0-only
 * TapeDeck creative punch layer. 2 KiB history, two 11.6 ms windowed grains.
 * No allocation, feedback, flash reads or unbounded work in the audio callback.
 * These are master-bus effects; input monitoring is mixed afterwards. */
static unsigned td_creative_mask,td_creative_busy;
static int16_t td_grain_buf[1024] __attribute__((section(".pool")));
static uint32_t td_cwr,td_cphase,td_crng=0x18397u,td_cstart[2];
static int32_t td_cwet[8],td_drop=32768;
static int td_creative_mix(int dry,int wet,int w){return dry+mulq15(wet-dry,w);}
static int td_fold(int x){int v=(clamp(x,-32767,32767)*4+32768)&131071;return v<65536?v-32768:98303-v;}
static __attribute__((noinline)) void td_creative_process(int32_t*l,int32_t*r,unsigned n){
 uint32_t beat=beat_samples();if(beat<1)beat=1;
 uint32_t phase_step=4294967295u/beat;
 td_creative_busy=0;
 for(unsigned i=0;i<n;i++){
  int a=l[i],b=r[i];unsigned p=td_cwr&511;
  td_grain_buf[td_cwr&1023]=clamp((a+b)/2,-32767,32767);
  for(unsigned k=0;k<8;k++)td_cwet[k]+=clamp(((td_creative_mask>>k)&1?32768:0)-td_cwet[k],-256,256);
  if(td_cwet[0]||td_cwet[1]){
   int grain=0;
   for(unsigned g=0;g<2;g++){
    unsigned pos=(p+g*256)&511;
    if(pos==0){td_crng=td_crng*1664525u+1013904223u;td_cstart[g]=td_cwr-512-(td_crng&255);}
    unsigned at=td_cstart[g]+pos;
    if(td_creative_mask&2)at=td_cstart[g]+511-pos;
    int w=pos<256?pos:512-pos;grain+=td_grain_buf[at&1023]*w/256;
   }
   int w=td_cwet[0]>td_cwet[1]?td_cwet[0]:td_cwet[1];
   a=td_creative_mix(a,grain,w);b=td_creative_mix(b,grain,w);
  }
  /* Four pulses per beat, sinusoidal rather than hard gating. */
  td_cphase+=phase_step;
  if(td_cwet[2]){int gain=20480+sine_i(td_cphase*4)/4;a=td_creative_mix(a,mulq15(a,gain),td_cwet[2]);b=td_creative_mix(b,mulq15(b,gain),td_cwet[2]);}
  if(td_cwet[3]){int carrier=sine_i(td_cwr*11979049u);a=td_creative_mix(a,mulq15(a,carrier),td_cwet[3]);b=td_creative_mix(b,mulq15(b,carrier),td_cwet[3]);}
  if(td_cwet[4]){int pan=sine_i(td_cphase)/2;a=td_creative_mix(a,mulq15(a,16384+pan),td_cwet[4]);b=td_creative_mix(b,mulq15(b,16384-pan),td_cwet[4]);}
  if(td_cwet[5]){int delay=160+sine_i(td_cwr*194783u)/512+sine_i(td_cwr*1655655u)/4096;int y=td_grain_buf[(td_cwr-delay)&1023];a=td_creative_mix(a,y,td_cwet[5]);b=td_creative_mix(b,y,td_cwet[5]);}
  if(td_cwet[6]){a=td_creative_mix(a,td_fold(a),td_cwet[6]);b=td_creative_mix(b,td_fold(b),td_cwet[6]);}
  if(td_cwet[7]){if(!(td_cwr&2047)){td_crng=td_crng*1664525u+1013904223u;td_drop=(td_crng>>29)<3?2048:32768;}a=td_creative_mix(a,mulq15(a,td_drop),td_cwet[7]);b=td_creative_mix(b,mulq15(b,td_drop),td_cwet[7]);}
  l[i]=a;r[i]=b;td_cwr++;
 }
 for(unsigned k=0;k<8;k++)td_creative_busy|=td_cwet[k]!=0;
}
