/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
/* Stock samples and user flash/RAM share an address space. Integer rebasing
 * prevents out-of-bounds C-array indexing when the stock bank is empty. */
static inline uint32_t fm1_sample_byte(uintptr_t base,uint32_t off){return *(const volatile uint8_t *)(base+off);}
