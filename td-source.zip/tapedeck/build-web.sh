#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
ROOT="$PWD"
PYTHON=${PYTHON:-/Users/nickthechen/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3}
export EMSDK_PYTHON="$PYTHON"
cd tapedeck/firmware
"$PYTHON" "${EMCC_PY:-$ROOT/.tools/emsdk/upstream/emscripten/emcc.py}" -O2 -ffp-contract=off -std=gnu99 -w -DFELUCCA_CPU2=0 '-DFELUCCA_VERSION="1.3-tapedeck"' -Ibuild/gen -Ifirmware/src -Ifirmware/hal -Ifirmware/bsp/chip -Ifirmware/bsp/boards/fm1 --no-entry -sSTANDALONE_WASM -sSTACK_SIZE=1048576 -sINITIAL_MEMORY=33554432 -sFILESYSTEM=0 -o ../web/tapedeck.wasm web/emu/felucca_web.c
