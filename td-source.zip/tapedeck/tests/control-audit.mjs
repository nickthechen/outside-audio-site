import fs from 'node:fs';import assert from 'node:assert/strict';import {encodeSlot} from '../web/sample.js';
const root=new URL('../',import.meta.url),{instance}=await WebAssembly.instantiate(fs.readFileSync(new URL('web/tapedeck.wasm',root)),{env:{emscripten_notify_memory_growth(){}}});const e=instance.exports;e._initialize?.();e.web_nor_erase();e.web_boot();
function render(n){while(n){let k=Math.min(128,n);e.web_render(k);n-=k;}}
function press(label){e.web_buttons(1<<label);render(2205);e.web_buttons(0);render(2205);}
render(25000);for(let slot=0;slot<2;slot++){const a=encodeSlot(Float32Array.from({length:22050},(_,i)=>.2*Math.sin(i*.04)),22050,'AUDIT');new Uint8Array(e.memory.buffer,e.td_slot(slot),81920).set(a);assert(e.td_upload(slot));}
e.td_param(0,0);press(10);assert.equal(e.td_get(34)&1,1);e.td_param(0,1);const before=e.td_get(23);e.web_buttons(1<<12);render(44100);assert.equal(e.td_get(41),1);assert(e.td_get(23)>before);assert.equal(e.td_get(34)&1,1,'random on II preserves I');e.web_buttons(0);render(256);assert.equal(e.td_get(41),0);
press(13);assert.equal(e.td_get(42),1);e.td_param(0,0);assert.equal(e.td_get(42),0);e.td_param(0,1);press(13);assert.equal(e.td_get(42),0);
// The actual GLOBAL and REC buttons reach library deletion, not record capture.
press(5);assert.equal(e.td_get(17),7);assert.equal(e.td_get(40),0);press(11);assert.equal(e.td_get(43),1);assert.equal(e.td_get(7),0);assert.equal(e.td_get(10),22050);press(11);assert.equal(e.td_get(10),0);assert.equal(e.td_get(13),4);e.td_param(0,0);assert.equal(e.td_get(10),22050,'other tape remains');press(5);assert.equal(e.td_get(40),1);press(5);assert.equal(e.td_get(40),2);press(5);assert.equal(e.td_get(40),0);
console.log('PASS: label-to-panel event routing for OCT−/OCT+, independent lanes, GLOBAL library, physical REC confirmation/deletion, no accidental capture, other tape preservation, GLOBAL page cycle');
