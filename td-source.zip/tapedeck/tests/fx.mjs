import {encodeSlot} from '../web/sample.js';import fs from 'node:fs';import assert from 'node:assert/strict';
const wasm=fs.readFileSync(new URL('../web/tapedeck.wasm',import.meta.url));
async function boot(){const {instance}=await WebAssembly.instantiate(wasm,{env:{emscripten_notify_memory_growth(){}}});const e=instance.exports;e._initialize?.();e.web_nor_erase();e.web_boot();render(e,25000);const tone=encodeSlot(Float32Array.from({length:22050},(_,i)=>.2*Math.sin(i*.04)),22050,'FXTEST');new Uint8Array(e.memory.buffer,e.td_slot(0),81920).set(tone);e.td_upload(0);return e;}
function render(e,n){const out=[];while(n){const k=Math.min(128,n);e.web_render(k);for(const v of new Float32Array(e.memory.buffer,e.web_out_l(),k)){assert(Number.isFinite(v));assert(Math.abs(v)<=1);out.push(v);}n-=k;}return out;}
let e=await boot();
// A tap opens the rack; another tap closes it. A long hold never changes the page.
e.web_buttons(1);render(e,2205);e.web_buttons(0);render(e,2205);assert.equal(e.td_get(17),5);e.web_buttons(1);render(e,2205);e.web_buttons(0);render(e,2205);assert.equal(e.td_get(17),0);
e.web_buttons(1);render(e,18000);e.web_buttons(0);render(e,2205);assert.equal(e.td_get(17),0);
// Armed step entry must not receive punch keys. Use the real hardware key/button path.
e.td_page_select(2);for(let j=0;j<16;j++){e.td_note(0,1);e.td_note(0,0);e.td_knob_turn(0,1);}e.td_knob_turn(0,-15);e.td_page_select(4);e.td_action(4);render(e,256);let hits=e.td_get(23);e.web_buttons(1);e.web_keys(1);render(e,256);assert.equal(e.td_get(23),hits);assert.equal(e.td_get(21),0);assert.equal(e.td_get(18),2);assert.equal(e.td_get(27),1);
e.web_buttons(0);render(e,256);assert.equal(e.td_get(27),0);assert.equal(e.td_get(23),hits);e.web_keys(0);render(e,256);assert.equal(e.td_get(21),0);assert.equal(e.td_get(17),4);
e.td_param(4,120);e.web_buttons(1);e.web_keys(1<<21);render(e,256);hits=e.td_get(23);render(e,44100);assert.equal(e.td_get(23)-hits,8,'sequence clock continues under punch FX');assert.equal(e.td_get(21),0,'punch never step-records');e.web_keys(0);e.web_buttons(0);render(e,256);
e.td_action(2);render(e,256);
// All browser punch keys acquire and release effects without adding chop events.
e.td_page_select(0);e.td_action(1);render(e,4410);for(let key=0;key<16;key++){hits=e.td_get(23);e.td_fx_hold(1);e.td_note(key,1);render(e,9000);assert.equal(e.td_get(23),hits);assert.equal(e.td_get(27),1<<key);e.td_fx_hold(0);render(e,256);assert.equal(e.td_get(27),0);e.td_note(key,0);render(e,256);}
// Every rack control changes actual audio, and punching drive restores its base value.
for(let k=0;k<4;k++){let dry=await boot(),wet=await boot();wet.td_page_select(5);wet.td_knob_turn(k,90);dry.td_action(1);wet.td_action(1);const a=render(dry,44100),b=render(wet,44100);let diff=0;for(let j=0;j<a.length;j++)diff+=Math.abs(a[j]-b[j]);assert(diff>1,`FX ${k} must change audio`);assert.equal(wet.td_get(28+k),90);}
e.td_page_select(5);e.td_knob_turn(1,35);render(e,256);assert.equal(e.td_get(32),35);e.td_fx_hold(1);e.td_note(14,1);render(e,256);assert.equal(e.td_get(32),100);e.td_fx_hold(0);render(e,256);assert.equal(e.td_get(32),35);e.td_note(14,0);
render(e,4410);fs.writeFileSync(new URL('../fx-rack.rgb565',import.meta.url),new Uint8Array(e.memory.buffer,e.web_screen(),115200));e.td_fx_hold(1);e.td_note(13,1);render(e,4410);fs.writeFileSync(new URL('../fx-punch.rgb565',import.meta.url),new Uint8Array(e.memory.buffer,e.web_screen(),115200));
console.log('PASS: FX tap/hold, hardware key ownership, no sequence interruption or step recording, 16 punch keys, four audible rack effects, base-value restoration');
