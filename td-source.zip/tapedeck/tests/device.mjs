import assert from 'node:assert/strict';import {sendTape} from '../web/device.js';import {encodeSlot} from '../web/sample.js';
const data=encodeSlot(Float32Array.from({length:1000},(_,i)=>.2*Math.sin(i*.05)),22050,'TEST');
for(const name of ['TapeDeck FM-1','Felucca']){
 let handler,writes=0;const input={name,async open(){},async close(){},addEventListener(_,f){handler=f;},removeEventListener(){handler=null;}};
 const output={name,async open(){},async close(){},send(d){const cmd=d[4];writes++;const reply=cmd===12?[d[5],d[6],d[7],d[8],0]:[d[5]||0,0];queueMicrotask(()=>handler({data:new Uint8Array([0xf0,0x7d,0x46,0x4c,cmd,...reply,0xf7])}));}};
 Object.defineProperty(globalThis,'navigator',{configurable:true,value:{requestMIDIAccess:async()=>({inputs:new Map([[1,input]]),outputs:new Map([[1,output]])})}});
 await sendTape(1,data,()=>{});assert(writes>=4);
}
console.log('PASS: sample upload detects both TapeDeck FM-1 and legacy Felucca USB names and completes begin/write/end protocol');
