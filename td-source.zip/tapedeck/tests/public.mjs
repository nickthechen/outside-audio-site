import fs from 'node:fs';import assert from 'node:assert/strict';import{encodeSlot}from'../web/sample.js';
const {instance}=await WebAssembly.instantiate(fs.readFileSync(new URL('../web/tapedeck.wasm',import.meta.url)),{env:{emscripten_notify_memory_growth(){}}});const e=instance.exports;e._initialize?.();e.web_nor_erase();e.web_boot();
function render(n){let sum=0;while(n){const k=Math.min(128,n);e.web_render(k);for(const x of new Float32Array(e.memory.buffer,e.web_out_l(),k)){assert(Number.isFinite(x));sum+=x*x;}n-=k;}return sum;}
render(25000);for(let lane=0;lane<2;lane++){e.td_param(0,lane);assert.equal(e.td_get(10),0);e.td_action(1);e.td_note(0,1);assert.equal(render(4410),0,'empty public slot stays silent');}
e.td_param(0,99);assert.equal(e.td_get(0),1,'two available tapes');
for(let slot=0;slot<2;slot++){const data=encodeSlot(Float32Array.from({length:12000},(_,i)=>.1*Math.sin(i*(slot+1)*.03)),22050,'TEST');new Uint8Array(e.memory.buffer,e.td_slot(slot),81920).set(data);assert.equal(e.td_upload(slot),1);assert.equal(e.td_get(0),slot);assert.equal(e.td_get(10),12000);}
for(let slot=0;slot<2;slot++){e.td_param(0,slot);e.td_action(1);render(128);}assert.equal(e.td_get(34),3);assert(render(44100)>0);assert.equal(e.td_get(34),3);
e.td_action(2);render(128);e.td_page_select(4);e.td_action(4);render(128);assert.equal(e.td_get(18),2);e.td_note(2,1);render(128);assert.equal(e.td_get(22),2);e.td_action(4);render(128);assert.equal(e.td_get(19),0);
console.log('PASS: no bundled recordings; empty slots silent; two imported tapes play together; recording workflow intact');
