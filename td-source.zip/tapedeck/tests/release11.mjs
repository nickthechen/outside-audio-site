import fs from 'node:fs';import assert from 'node:assert/strict';import {encodeSlot} from '../web/sample.js';
const wasm=fs.readFileSync(new URL('../web/tapedeck.wasm',import.meta.url));
async function boot(flash){const {instance}=await WebAssembly.instantiate(wasm,{env:{emscripten_notify_memory_growth(){}}});const e=instance.exports;e._initialize?.();e.web_nor_erase();if(flash)new Uint8Array(e.memory.buffer,e.web_nor(),1048576).set(flash);e.web_boot();render(e,25000);return e;}
function render(e,n){let power=0;while(n){const k=Math.min(128,n);e.web_render(k);for(const ptr of [e.web_out_l(),e.web_out_r()])for(const v of new Float32Array(e.memory.buffer,ptr,k)){assert(Number.isFinite(v));assert(Math.abs(v)<=.501,'limited DAC output');power+=v*v;}n-=k;}return power;}
function feed(e,n,amplitude=.2){let power=0;while(n){const k=Math.min(128,n),input=new Float32Array(e.memory.buffer,e.td_input(),256);for(let i=0;i<k;i++){input[2*i]=amplitude*Math.sin((n+i)*.07);input[2*i+1]=-input[2*i];}e.td_capture(k);power+=render(e,k);n-=k;}return power;}
function pixel(e,x,y){return new DataView(e.memory.buffer).getUint16(e.web_screen()+2*(y*240+x),false);}
let e=await boot();assert(feed(e,44100)>1,'input audible BEFORE REC');assert.equal(e.td_get(7),0);assert.equal(e.td_get(12),0,'monitoring does not record');assert.equal(e.td_get(46),1);render(e,8820);assert.equal(e.td_get(46),0,'disconnect clears monitoring');assert.equal(render(e,4410),0,'disconnect leaves no stale samples');
// ENV and GLOBAL dots follow subpages, not tape selection; single pages have none.
const cream=((243>>3)<<11)|((226>>2)<<5)|(184>>3);
for(const page of [6,7]){e.td_page_select(page);for(let j=0;j<3;j++){render(e,4410);for(let k=0;k<3;k++)assert.equal(pixel(e,107+k*13,76)===cream,k===j);e.td_param(0,1);render(e,4410);assert.equal(pixel(e,107+j*13,76),cream);if(j<2)e.td_page_select(page);}}
e.td_page_select(0);render(e,4410);for(let k=0;k<3;k++)assert.notEqual(pixel(e,107+k*13,76),cream);
// Import boundary rejects removed third deck; recording and SAVE target Tape II only.
assert.equal(e.td_slot(2),0);assert.equal(e.td_upload(2),0);
const original=encodeSlot(Float32Array.from({length:22050},(_,i)=>.2*Math.sin(i*.06)),22050,'KEEP');new Uint8Array(e.memory.buffer,e.td_slot(0),81920).set(original);assert.equal(e.td_upload(0),1);
e.td_action(3);render(e,256);assert.equal(e.td_get(7),1);
// Mono content captures at the original 11.025 kHz; monitor remains stereo.
for(let j=0;j<1100;j++){const input=new Float32Array(e.memory.buffer,e.td_input(),256);for(let i=0;i<128;i++)input[2*i]=input[2*i+1]=.2*Math.sin((j*128+i)*.04);e.td_capture(128);render(e,128);}
e.td_action(3);render(e,4410);assert.equal(e.td_get(7),0);assert.equal(e.td_get(0),1);assert(e.td_get(10)>30000);e.td_save_take();render(e,4410);assert.equal(e.td_get(13),1);assert.equal(e.td_get(45),0,"saved tape is Flash, not RAM");const flash=new Uint8Array(e.memory.buffer,e.web_nor(),1048576).slice();assert.deepEqual(flash.slice(0xa0000,0xa0000+81920),original);
e=await boot(flash);e.td_param(0,1);assert(e.td_get(10)>30000);e.td_action(1);assert(render(e,44100)>1,'saved take sounds after reboot');
// Stress both decks, FX, reverse and rapid retriggers with monitored full-scale input.
e.td_param(0,0);e.td_param(6,1);e.td_param(2,24);e.td_action(1);render(e,256);e.td_page_select(5);for(let k=0;k<4;k++)e.td_knob_turn(k,100);for(let j=0;j<160;j++){e.td_param(0,j%2);e.td_note(j%16,1);feed(e,2048,1);e.td_note(j%16,0);}e.td_action(2);render(e,44100);
console.log('PASS: monitoring before REC, disconnect, DAC limiting, ENV/GLOBAL page dots, two-deck bounds, recording/save/reboot preservation, reverse/FX/monitor stress');
