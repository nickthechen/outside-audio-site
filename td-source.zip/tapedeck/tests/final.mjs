import fs from'node:fs';import assert from'node:assert/strict';import{encodeSlot}from'../web/sample.js';
const bytes=fs.readFileSync(new URL('../web/tapedeck.wasm',import.meta.url));
async function boot(flash){const{instance}=await WebAssembly.instantiate(bytes,{env:{emscripten_notify_memory_growth(){}}});const e=instance.exports;e._initialize?.();e.web_nor_erase();if(flash)new Uint8Array(e.memory.buffer,e.web_nor(),1048576).set(flash);e.web_boot();render(e,25000);return e;}
function render(e,n){let power=0;while(n){const k=Math.min(128,n);e.web_render(k);for(const x of new Float32Array(e.memory.buffer,e.web_out_l(),k)){assert(Number.isFinite(x));assert(Math.abs(x)<=1);power+=x*x;}n-=k;}return power;}
let e=await boot();for(let slot=0;slot<2;slot++){const data=encodeSlot(Float32Array.from({length:22050},(_,i)=>.2*Math.sin(i*(slot+1)*.03)),22050,'TAPE'+slot);new Uint8Array(e.memory.buffer,e.td_slot(slot),81920).set(data);assert.equal(e.td_upload(slot),1);}e.td_param(0,0);e.td_param(4,120);
// Physical OCT− is momentary, timed at the current 1/16 rate.
let hits=e.td_get(23);e.web_buttons(1<<12);assert(render(e,44100)>0);assert.equal(e.td_get(23)-hits,8);assert.equal(e.td_get(41),1);e.web_buttons(0);render(e,256);hits=e.td_get(23);render(e,44100);assert.equal(e.td_get(23),hits);assert.equal(e.td_get(41),0);
// Physical OCT+ toggles persistent repeat; pressing a new chop updates it.
e.web_buttons(1<<13);render(e,256);e.web_buttons(0);render(e,256);assert.equal(e.td_get(42),1);hits=e.td_get(23);render(e,44100);assert.equal(e.td_get(23)-hits,8);e.td_note(7,1);render(e,128);e.td_note(7,0);render(e,6000);assert.equal(e.td_get(42),1);e.web_buttons(1<<13);render(e,256);e.web_buttons(0);assert.equal(e.td_get(42),0);
// STOP wins even if random is still held, until a fresh press.
e.web_buttons(1<<12);render(e,256);e.td_action(2);render(e,256);hits=e.td_get(23);render(e,44100);assert.equal(e.td_get(23),hits);e.web_buttons(0);render(e,256);
// Library: first delete press and an expired confirmation cannot erase audio.
e.td_page_select(7);assert.equal(e.td_get(17),7);assert(e.td_get(44)>0);e.td_action(8);render(e,256);assert.equal(e.td_get(43),1);assert.equal(e.td_get(10),22050);render(e,4*44100);e.td_action(8);render(e,256);assert.equal(e.td_get(10),22050);e.td_action(8);render(e,4410);assert.equal(e.td_get(13),4);assert.equal(e.td_get(10),0);
const flash=new Uint8Array(e.memory.buffer,e.web_nor(),1048576).slice();e=await boot(flash);e.td_param(0,0);assert.equal(e.td_get(10),0);for(const slot of[1]){e.td_param(0,slot);assert.equal(e.td_get(10),22050,'other slots preserved');}
// GLOBAL settings change only selected tape; device settings drive the shared clock/bank.
e.td_param(0,0);
e.td_page_select(7);e.td_page_select(7);assert.equal(e.td_get(40),1);e.td_knob_turn(0,5);assert.equal(e.td_get(2),5);e.td_param(0,1);assert.equal(e.td_get(2),0);e.td_page_select(7);e.td_knob_turn(0,4);e.td_knob_turn(3,1);assert.equal(e.td_get(4),130);assert.equal(e.td_get(16),1);
for(let panel=0;panel<3;panel++){while(e.td_get(40)!==panel)e.td_page_select(7);render(e,4410);fs.writeFileSync(new URL(`../global-${panel}.rgb565`,import.meta.url),new Uint8Array(e.memory.buffer,e.web_screen(),115200));}
console.log('PASS: physical octave random/latch timing, latch update/release, stop priority, confirmed deletion/reboot, other tapes preserved, GLOBAL settings');
