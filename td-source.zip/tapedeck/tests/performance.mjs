import fs from 'node:fs';import assert from 'node:assert/strict';import {encodeSlot} from '../web/sample.js';
const bytes=fs.readFileSync(new URL('../web/tapedeck.wasm',import.meta.url));
const keys=[1,3,5,8,10,13,15,17,20,22];
function render(e,n){const out=[];while(n){let k=Math.min(128,n);e.web_render(k);for(const x of new Float32Array(e.memory.buffer,e.web_out_l(),k)){assert(Number.isFinite(x));assert(Math.abs(x)<=.501);out.push(x);}n-=k;}return out;}
async function boot(){let {instance}=await WebAssembly.instantiate(bytes,{env:{emscripten_notify_memory_growth(){}}});let e=instance.exports;e._initialize?.();e.web_nor_erase();e.web_boot();render(e,25000);for(let slot=0;slot<2;slot++){let data=encodeSlot(Float32Array.from({length:44100},(_,i)=>.18*Math.sin(i*.13)+.04*Math.sin(i*.79)),22050,'TEST');new Uint8Array(e.memory.buffer,e.td_slot(slot),81920).set(data);e.td_upload(slot);}e.td_param(0,0);e.td_param(4,120);return e;}
for(let key=0;key<10;key++){let e=await boot();e.web_keys(1<<keys[key]);render(e,128);assert.equal(e.td_get(53),1<<key,`physical key ${key}`);if(key<3){let hits=e.td_get(23);render(e,44100);assert.equal(e.td_get(23)-hits,4<<key);}if(key>=5&&key<=7)assert.equal(e.td_get(54),key-4);e.web_keys(0);render(e,256);assert.equal(e.td_get(53),0);assert.equal(e.td_get(2),0,'base pitch untouched');}
// Octave changes affect a running voice immediately and restore its normal speed.
for(const [key,ratio] of [[3,.5],[4,2]]){let e=await boot();e.td_action(1);render(e,1024);let p=e.td_get(9);e.web_keys(1<<keys[key]);render(e,2048);let moved=e.td_get(9)-p;assert(Math.abs(moved/(1024*ratio)-1)<.03,`octave ${key}: ${moved}`);p=e.td_get(9);e.web_keys(0);render(e,2048);assert(Math.abs((e.td_get(9)-p)/1024-1)<.03);}
// Each filter affects actual audio while leaving the other tape audible.
for(const key of [8,9]){let dry=await boot(),wet=await boot();dry.td_action(1);wet.td_action(1);wet.web_keys(1<<keys[key]);let a=render(dry,11025),b=render(wet,11025);assert(a.reduce((s,x,i)=>s+Math.abs(x-b[i]),0)>1);wet.td_param(0,1);wet.td_action(1);render(wet,1000);assert.equal(wet.td_get(34)&3,3);}
// STOP dominates OP chopping until release; FX ownership never leaks into direct controls.
let e=await boot();e.web_keys(1<<1);render(e,128);e.td_action(2);render(e,128);let hits=e.td_get(23);render(e,44100);assert.equal(e.td_get(23),hits);e.web_keys(0);render(e,128);e.web_buttons(1);e.web_keys(1<<1);render(e,128);assert.equal(e.td_get(53),0);e.web_buttons(0);render(e,128);assert.equal(e.td_get(53),0);e.web_keys(0);render(e,128);
// Hold-only SCL preserves every underlying page, including short taps.
for(let page=0;page<8;page++){e.td_page_select(0);if(page)e.td_page_select(page);let old=e.td_get(17);e.web_buttons(2);render(e,2205);e.web_buttons(0);render(e,2205);assert.equal(e.td_get(17),old);assert.equal(e.td_get(50),0);}
// All eight replacement effects change real audio and release their masks.
for(const key of [0,1,2,4,5,8,9,13]){let dry=await boot(),wet=await boot();dry.td_action(1);wet.td_action(1);render(dry,4096);render(wet,4096);wet.td_fx_hold(1);wet.td_note(key,1);let a=render(dry,22050),b=render(wet,22050);const diff=a.reduce((s,x,i)=>s+Math.abs(x-b[i]),0);assert(diff>1,`creative FX ${key} audible: ${diff}`);wet.td_note(key,0);wet.td_fx_hold(0);render(wet,1024);assert.equal(wet.td_get(55),0);}
// Stack the new layer, both filters, pitch, delay and both decks without invalid output.
e=await boot();e.td_action(1);render(e,128);e.td_param(0,1);e.td_action(1);render(e,128);for(const key of [3,5,8,9])e.td_perform(key,1);render(e,128);e.td_fx_hold(1);render(e,128);assert.equal(e.td_get(53),808,'pre-held direct controls coexist with FX');for(let k=0;k<16;k++)e.td_note(k,1);render(e,441000);e.td_fx_hold(0);render(e,44100);
console.log('PASS: ten physical performance keys, three chop clocks, live octave ratios, audible filters, ownership/STOP, hold-only SCL, eight audible new effects, stacked stress');

for(const key of [3,4,8,9]){let dry=await boot(),wet=await boot();for(const x of [dry,wet]){x.td_param(0,1);x.td_action(1);render(x,1024);x.td_param(0,0);}wet.web_keys(1<<keys[key]);assert.deepEqual(render(dry,8192),render(wet,8192),'other deck audio unchanged');}

for(const key of [5,6,7]){let dry=await boot(),wet=await boot();dry.td_action(1);wet.td_action(1);wet.web_keys(1<<keys[key]);let a=render(dry,44100),b=render(wet,44100);assert(a.reduce((s,x,i)=>s+Math.abs(x-b[i]),0)>1,`delay ${key} changes audio`);}
