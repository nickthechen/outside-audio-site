"""TapeDeck 1.3 user manual. Vector artwork; no sample recordings or external assets."""
from pathlib import Path
from math import sin,cos,pi
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from pypdf import PdfReader
root=Path(__file__).resolve().parents[1];out=root/'output/pdf/TapeDeck-1.3-Workflow-Manual.pdf'
c=canvas.Canvas(str(out),pagesize=(612,792));c.setTitle('TapeDeck 1.3 - Workflow Manual');c.setAuthor('TapeDeck')
cream='#F3E2B8';walnut='#3B2A1E';face='#5A4332';dark='#1B120C';amber='#E8A33C';red='#C34D3D'
page=0
styles={}
for color in [dark,cream,face]:
 for size in [10,11,12,14]:styles[(color,size)]=ParagraphStyle('body',fontName='Helvetica',fontSize=size,leading=size*1.42,textColor=HexColor(color),spaceAfter=0)
def rect(x,y,w,h,col,r=0):
 c.setFillColor(HexColor(col));c.setStrokeColor(HexColor(col));
 if r:c.roundRect(x,792-y-h,w,h,r,fill=1,stroke=0)
 else:c.rect(x,792-y-h,w,h,fill=1,stroke=0)
def text(x,y,s,size=11,col=dark,font='Helvetica'):
 c.setFillColor(HexColor(col));c.setFont(font,size);c.drawString(x,792-y-size,s)
def para(x,y,s,w=516,size=11,col=dark):
 p=Paragraph(s,styles[(col,size)]);ww,h=p.wrap(w,700);assert y+h<738,(page,s[:40],y,h);p.drawOn(c,x,792-y-h);return y+h

def line(x,y,xx,yy,col,width=1):c.setStrokeColor(HexColor(col));c.setLineWidth(width);c.line(x,792-y,xx,792-yy)
def disc(x,y,r,col):c.setFillColor(HexColor(col));c.circle(x,792-y,r,fill=1,stroke=0)
def reel(x,y,r):
 disc(x+2,y+4,r,dark);disc(x,y,r,'#B59D78');disc(x,y,r-5,dark)
 for rr in range(16,int(r)-8,5):
  c.setStrokeColor(HexColor(face));c.setLineWidth(1);c.circle(x,792-y,rr,fill=0,stroke=1)
 for a in [0,2*pi/3,4*pi/3]:
  xx=x+cos(a)*r*.57;yy=y+sin(a)*r*.57;disc(xx,yy,r*.21,'#B59D78');disc(xx,yy,r*.12,dark)
 disc(x,y,r*.29,'#D1BB93');disc(x,y,r*.12,dark)
def start(kicker,title,subtitle):
 global page
 page+=1;rect(0,0,612,792,cream);rect(0,0,612,12,walnut)
 text(48,33,'TAPEDECK',11,walnut,'Helvetica-Bold');text(398,33,'FIELD MANUAL / 1.3',10,face)
 line(48,58,564,58,face,.6);text(48,80,kicker,10,face,'Helvetica-Bold');text(48,104,title,32,walnut,'Times-Italic');para(48,151,subtitle,size=11)
 line(48,747,564,747,face,.5);text(48,759,'M-VAVE FM-1  /  TWO-DECK SAMPLER',8,face);text(537,757,f'{page:02}',11,walnut,'Helvetica-Bold')
def end():c.showPage()
def block(y,title,body):
 text(48,y,title,15,walnut,'Helvetica-Bold');return para(48,y+25,body)+20

def table(y,rows,widths=(120,396),size=11):
 for idx,row in enumerate(rows):
  ps=[];heights=[]
  for j,cell in enumerate(row):
   p=Paragraph(cell,styles[(cream if idx==0 else dark,size)]);_,h=p.wrap(widths[j]-22,500);ps.append(p);heights.append(h)
  h=max(heights)+18;assert y+h<734,(page,y,h)
  rect(48,y,516,h,walnut if idx==0 else ('#E8D4A6' if idx%2 else '#F6E8C9'))
  x=48
  for j,p in enumerate(ps):p.drawOn(c,x+11,792-y-9-heights[j]);x+=widths[j]
  y+=h
 return y+18

# 1: cover
page=1;rect(0,0,612,792,walnut)
for y in range(0,792,9):line(0,y,612,y,face,.22)
text(48,43,'TWO TAPES. A WHOLE PERFORMANCE.',11,cream,'Helvetica-Bold')
text(45,83,'TapeDeck',76,cream,'Times-Italic');text(49,179,'THE WORKFLOW MANUAL',14,amber,'Helvetica-Bold')
rect(45,239,522,280,dark,12);rect(48,235,516,280,face,12)
for x in [62,550]:
 for y in [250,500]:disc(x,y,4,'#B59D78');line(x-2,y+2,x+2,y-2,dark)
reel(181,345,75);reel(431,345,75)
rect(83,417,446,24,dark)
for x in range(88,521,2):line(x,429,x+1,429+sin(x*.24)*6*sin(x*.07),amber,.8)
for x in [120,210,300,390,480]:line(x,416,x,443,cream,.8)
rect(302,415,4,29,red)
rect(164,459,282,31,cream,3);text(178,466,'Tape I + Tape II / play it by hand',15,walnut,'Times-Italic')
text(48,560,'Chop. Layer. Throw. Let go.',26,cream,'Times-Italic')
para(48,610,'A practical guide to recording, live chopping, two-lane patterns, momentary performance keys and the creative punch-in rack.',500,12,cream)
line(48,710,564,710,amber,.6);text(48,729,'FIRMWARE 1.3  /  FM-1_915',10,cream);text(48,750,'Custom firmware for M-VAVE FM-1. Built on Felucca.',9,cream)
end()
# 2
start('01 / FIRST SESSION','Make a beat in five minutes','Begin with low MASTER volume. TapeDeck starts with no bundled recordings.')
y=205
y=block(y,'1. Put sound on the tapes','Use the installer\'s sampler/import page to load audio into Tape I and Tape II, then upload to the connected device. Browser preview storage and device storage are separate. An import replaces the chosen device slot; choose it carefully.')
y=block(y,'2. Set up drums and melody','Turn PRESETS to Tape I. On the home page, K2 chooses the number of splices: whole sample, 4, 8, 16, 32 or automatic. Press PLAY for a whole-tape loop. Turn PRESETS to Tape II and play the lower keys over your drums.')
y=block(y,'3. Play the upper keys','Hold OP1, OP2 or OP3 to repeat the last chop at 1/8, 1/16 or 1/32. Tap another lower key to change that chop. Hold OP4/OP5 to drop or raise its pitch by an octave; release to return.')
y=block(y,'4. Throw an effect, then let go','Hold OP6 for dotted-eighth delay, PIT for eighth-note delay or the upper GLO key for 1/32 delay. Hold FX and press a lower key for a creative punch effect. Release to remove the effect; delay and reverb tails can ring out.')
para(48,y,'<b>Find your next lesson:</b> Performance keys p3; recording and input gain p4; patterns p5; sample properties p6; creative FX p7; library, updates and quick reference p8.',size=10)
end()
#3
start('02 / PLAY THE PANEL','Your fingers are the sequencer','Upper labeled keys are momentary performance controls. Lower keys remain sample chops.')
# compact physical key illustration
rect(48,200,516,100,walnut,9)
black=[1,3,5,8,10,13,15,17,20,22,25];labels=['OP1','OP2','OP3','OP4','OP5','OP6','PIT','GLO','MONO','POLY','-']
for i in range(16):rect(58+i*31,256,25,32,cream,6)
for k,label in zip(black,labels):
 x=64+k*18;rect(x,210,29,37,face,6);text(x+3,222,label,6,cream,'Helvetica-Bold')
y=table(316,[['Hold','What happens'],['OP1 / OP2 / OP3','Repeat the last chop at 1/8 / 1/16 / 1/32. Highest held rate wins. Uses the current tempo, swing and gate.'],['OP4 / OP5','One octave down / up on the targeted tape, including an already playing sample. Holding both cancels the pitch offset.'],['OP6 / PIT / GLO key','Delay throws at dotted eighth / eighth / 1/32. Affects the combined mix. Fastest held choice wins; the last time remains for tails.'],['MONO / POLY','Low-pass / high-pass on the targeted tape. Release smoothly restores the dry sound.'],['OCT- / OCT+ buttons','Hold OCT- for random chops. Tap OCT+ to latch the last chop. Both use the current rhythmic settings.']],size=10)
para(48,y,'<b>Targeting:</b> the first held upper key captures the selected tape until all upper keys are released. Pitch and filters leave the other tape alone. Upper keys never write pattern events. OP repeats temporarily take priority over that tape\'s pattern; the clock keeps running. HOME stops playback and blocks held repeats until release.',size=10)
end()
#4
start('03 / RECORD & MONITOR','Hear it before you print it','USB audio sent by the computer is monitored at the local outputs. A cable alone is not an active audio stream.')
y=table(203,[['Hold SEL + turn','Input / performance control'],['K1','USB monitoring level. Default -24 dB; -60 means mute; 0 dB is unity. Start quietly and raise only as needed.'],['K2','Recording level, independent of monitoring. Default 0 dB; -60 means mute. No boost above unity.'],['K3 / K4','Shared chop rate / gate. Also used by random, latch and the automatic chop workflows.']],size=11)
y=block(y,'SEL is hold-only','The small button beside FX is labeled SEL (called SCL internally). Hold to show the input controls; release to return to the same page. A quick tap never leaves a sticky menu. SELECT, the rotary control, still changes tempo.')
y=block(y,'Capture, stop, then SAVE','Return HOME before recording. Send audio to TapeDeck FM-1, set levels, and press REC. Press REC again to finish, or capture stops at the RAM limit. The take becomes Tape II in RAM. SAVE writes it to Tape II flash and replaces that slot\'s previous saved sample. A RAM take is lost on restart unless saved or backed up.')
para(48,y,'<b>Performance shift:</b> hold SEL + OCT- for reverse chop repeats, or SEL + OCT+ for double-rate ratchets. Let go to return. Releasing SEL first does not accidentally engage normal random/latch.<br/><br/><b>Monitoring:</b> MASTER remains effective. STOP stops tapes, not the host\'s stream. Monitoring is excluded from the device\'s USB return. In the browser, MONITOR INPUT requests separate audio permission.',size=10)
end()
#5
start('04 / PATTERNS','Record the performance','Two independent tape lanes share a 1-16-step clock. One chop event fits in each step of each lane.')
y=block(203,'Live entry: SEQ + REC','Select a tape, press SEQ, then press REC. The clock starts and your lower-key taps are quantized to the nearest step. Turn PRESETS to the other tape and overdub its lane. Press REC again to end overdub while the sequence continues.')
y=table(y,[['SEQ knobs','Pattern clock'],['K1 / K2','Length: 1-16 steps / rate: 1/4, 1/8, 1/16, 1/32.'],['K3 / K4','Tempo: 40-240 BPM / swing.']],size=10)
y=block(y,'Step entry: EDIT','K1 selects the step. K2 chooses a slice; display 0 is a rest. K3 changes velocity; K4 changes gate. A lower key assigns and auditions its chop at the selected step. REC clears that step. Hold EDIT and press REC to clear the selected tape\'s lane.')
y=block(y,'Automatic ideas: ARP','K1 chooses forward, reverse, pendulum or random order. K2 is rate, K3 gate and K4 swing. PLAY starts/stops automatic chops on the selected tape. Rate and swing are shared with the other rhythmic workflows.')
para(48,y,'<b>Keep it musical:</b> program the drum lane first, then play the melody lane by hand. Use OP2 for a fill, OP3 briefly at the bar end, and release to let the underlying pattern resume. Punch FX keys do not become notes or sequence events.<br/><br/><b>Session-only:</b> patterns and settings are not saved by SAVE and reset at restart. SAVE stores sample audio only.',size=10)
end()
#6
start('05 / SHAPE YOUR SAMPLES','Make every chop count','ENV owns the selected tape\'s sample properties. Press ENV again to cycle its three panels.')
y=table(203,[['Page','K1 / K2 / K3 / K4'],['HOME','Tape / splices / pitch / level.'],['ENV 1 - Playback','Splices / pitch / mode / reverse. Modes: one-shot, gated, loop.'],['ENV 2 - Envelope','Attack / decay / release / level.'],['ENV 3 - Tone + mix','Tone / level / pitch / reverse.'],['LFO','Shape / rate / destination / depth.']],size=11)
y=block(y,'One-shot, gated or looped','One-shot lets a triggered chop play out. Gated follows the key gate. Loop repeats the chop while gated. Whole-tape PLAY is a separate loop action. Pitch changes playback speed as well as tuning; this is not time stretching.')
y=block(y,'Motion without another hand','LFO shapes are triangle, square and saw. Rates span 4 beats, 2 beats, 1 beat, half a beat and a quarter beat. Destinations are pitch, tone or level; depth 0 turns modulation off. The selected tape is the LFO target.')
para(48,y,'<b>Read the tape deck:</b> the red bar marks playback; cream splice tabs show chop boundaries. The label names the tape and shows slice count and BPM. The small lamps below the VU meter appear on ENV and GLOBAL only, indicating the current subpage. A performance key temporarily replaces the label with its action; it does not navigate away.',size=10)
end()
#7
start('06 / PUNCH-IN FX','Small gestures. Big changes.','Tap FX for the four-knob rack: delay, drive, reverb, flanger. Amount 0 is off. Hold FX + a lower key for the map below.')
rows=[['Key / effect','Sound'],['01 Granulize / 02 Scatter','Two overlapping micrograins from recent audio; Scatter reverses their reads. A short, gritty texture rather than long sample-cloud storage.'],['03 Tremolo / 04 Reverse','Smooth rhythmic level pulses / buffered reverse playback.'],['05 Ring mod / 06 Auto pan','Metallic 123 Hz ring modulation / tempo-linked stereo motion. Auto pan is clearest on headphones.'],['07 Tape stop / 08 Freeze','Decelerating tape sound / held granular snapshot.'],['09 Wow + flutter / 10 Wavefold','Wavering tape-speed texture / folded, brighter harmonics.'],['11 Flanger / 12 Phaser','Moving comb-filter sweep / moving phase notches.'],['13 Reverb throw / 14 Dropout','Send a hit into reverb / irregular level dropouts.'],['15 Distortion / 16 Crush','Saturated drive / reduced bit depth and sample-rate texture.']]
y=table(203,rows,widths=(182,334),size=10)
para(48,y,'<b>Stack with care:</b> effects act on the combined tape mix, before USB input monitoring. New texture effects can stack; older buffered effects such as reverse, freeze and tape stop share a buffer, so the most recently pressed one wins. Release FX or the key to return; bus tails can continue.<br/><br/><b>Try this:</b> hold OP2 for a rhythmic chop, then FX + key 01 for a grainy fill. Keep the level modest, add a short reverb throw, and release everything on the next downbeat. Upper keys newly pressed while FX is held are ignored until released.',size=10)
end()
#8
start('07 / KEEP YOUR TAPES','Library & quick reference','The upper GLO performance key is a delay throw. The GLO button beside EDIT opens the GLOBAL library.')
y=block(203,'Preview or remove a sample','Press GLOBAL to the first panel. K1 selects Tape I or II; PLAY previews it. Press REC, then REC again within three seconds to confirm deletion. This erases the selected slot and its pattern lane and stops playback. The other saved slot stays intact. A RAM label means an unsaved take; Flash means saved audio.')
y=table(y,[['Capacity / behavior','Current firmware'],['Two fixed tape slots','80 KiB each. Imports: up to about 7.38 s per slot at 22.05 kHz mono IMA ADPCM.'],['USB recording','About 5.85 s, 11.025 kHz mono IMA ADPCM, in a separate 32 KiB RAM buffer. SAVE replaces Tape II.'],['Deletion','Frees that slot for replacement; it does not enlarge the other slot or the recording buffer.'],['Reboot / update','Save or back up a RAM take first. Patterns and settings reset. Reload an old installer tab before installing.']],widths=(134,382),size=10)
y=block(y,'When something seems wrong','No audio? Check that the selected tape contains audio, then raise MASTER gradually. For USB monitoring, select TapeDeck FM-1 as the computer output and hold SEL + K1 to check gain. Missing controls after an update? Check the boot screen says Version 1.3; an old open installer can contain an older release.')
para(48,y,'<b>Release identity:</b> TapeDeck 1.3 / FM-1_915. This manual describes the custom firmware, not the stock FM synth. Built on the GPL-licensed Felucca project and its contributors: <link href="https://github.com/hugelton/Felucca" color="#5A4332">github.com/hugelton/Felucca</link>. Independent of M-VAVE. Corresponding source and license notices accompany the installer.',size=10)
end();c.save()
r=PdfReader(out);assert len(r.pages)==8
for p in r.pages:assert len(p.extract_text())>300
print(out)
