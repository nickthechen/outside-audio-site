"""Rasterize the bundled OFL Inter Tight font for the redistributable tape UI."""
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
root=Path(__file__).resolve().parents[1]
font=ImageFont.truetype(str(root/'firmware/assets/fonts/InterTight[wght].ttf'),11)
rows=[]
for code in range(32,127):
 im=Image.new('1',(12,14));ImageDraw.Draw(im).text((0,0),chr(code),font=font,fill=1)
 rows.append([min(12,max(2,round(font.getlength(chr(code)))))] + [sum((1<<x) for x in range(12) if im.getpixel((x,y))) for y in range(14)])
(root/'firmware/firmware/src/tape_font.h').write_text('/* Inter Tight raster; SIL OFL-1.1, see LICENSES/OFL-InterTight.txt. */\nstatic const uint16_t TD_FONT[95][15]={'+','.join('{'+','.join(map(str,r))+'}' for r in rows)+'};\n')
